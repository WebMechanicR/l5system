// ConsoleApplication64.cpp: ���������� ����� ����� ��� ����������� ����������.
//

#include "stdafx.h"
#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <Windows.h>
#include <mysql.h>
#include <sstream>

typedef long unsigned long ulong;
typedef std::string string;

std::string pathToRegMomsFile = "D:/L5_Storage/EURUSD/register_moments_data.dat";
std::string pathToMomsForRes = "D:/L5_Storage/EURUSD/moments_for_resolving_data.dat";
std::string l5Symbol = "eurusd";

class L5Exception : public std::exception {
  public:
	  L5Exception(string msg){
		  std::cout << ("!!!CRITICAL ERROR!!! " + msg) << std::endl;
	  }
};

class FOR_CONSOLE_CHECKING{
	public:
		ulong md5p1;
		char num;
};

class FOR_CONSOLE_RESOLVING{
	public:
		ulong inmd5p1;
		ulong inmd5p2;
		ulong outmd5p1;
		ulong outmd5p2;
		float* eff;
		unsigned int* st_moms;
		unsigned int* outmoms;
		char* signals;
		short deals;
};

class MOMENTS_FOR_RES_ROW{
	public:
		unsigned int start_moment;
		unsigned int end_moment;
		ulong md5p1;
		ulong md5p2;
		char signalType;
		float start_price;
		float end_price;
};


//TIME QUEUE
const int BUY_SIGNAL  = 1;
const int SELL_SIGNAL = 2;

class TIME_QUEUE_ROW{
	public:
		unsigned int moment;
		ulong prevPos;
		float price;
};

class TIME_QUEUE_REGISTER_ROW {
	public:
		ulong md5p1;
		ulong md5p2;
		unsigned int moment;
		char signalType;
		float price;
};

class TIME_QUEUE_REGISTER_ROW_POINTER{
	public:
		unsigned int moment;
		ulong pos;
		TIME_QUEUE_REGISTER_ROW* block;
		int blockSize;
		int posOfMaxForBuyReq;
		int posOfMaxForSellReq;
		unsigned int momentForBuyReq;
		unsigned int momentForSellReq;
		unsigned int start_moment;
		float priceForSellReq;
		float priceForBuyReq;
		bool only_load;
};

class TIME_QUEUE{
	private:
		ulong signalsNum;
		ulong registeredMomentsNum;
		HANDLE filehandle;
		HANDLE regFilehandle;
		HANDLE mut;
		std::vector<TIME_QUEUE_REGISTER_ROW_POINTER> rrpointers;
		bool Block();
		bool Free();
		unsigned int prevStartMomentInFinding;
		unsigned int prevLastMomentInFinding;
		int prevBlockIndexForBuyReq;
		int prevBlockIndexForSellReq;
		int prevPosInBlockForBuyReq;
		int prevPosInBlockForSellReq;
		ulong blocksSize;
		bool GetBlockInFinding(int index, TIME_QUEUE_REGISTER_ROW_POINTER& out, bool with_loaded = false);

	public:
		TIME_QUEUE();
		~TIME_QUEUE();
		bool SignalWrite(ulong prevPos, unsigned int moment, float price, ulong& outPos);
		bool ResolveQueue(ulong lastPos, unsigned int** outMoments, float** prices, int& outSize);
		bool Clear();
		bool RegisterMoment(ulong md5p1, ulong md5p2, unsigned int moment, char signalType, float price);
		bool FindPacketsInArea(unsigned int start_time, unsigned int end_time, float start_price, char requiredSignalType, ulong&outmd5p1, ulong&outmd5p2, float& efficency, unsigned int& outmoment);
		ulong GetSignalsNum(){ return signalsNum; }
		ulong GetRegisteredNum() { return registeredMomentsNum; }
		ulong GetSizePointersBuffForFindingPackets() { return rrpointers.size(); }
		void  ClearBuffOfRegisteredMoments();
};

TIME_QUEUE::TIME_QUEUE(){
		prevStartMomentInFinding = prevLastMomentInFinding = 0;
		prevBlockIndexForBuyReq = prevBlockIndexForSellReq = prevPosInBlockForBuyReq = prevPosInBlockForSellReq = 0;
		blocksSize = 0;

	
		mut = CreateMutexEx(0,0,0,SYNCHRONIZE|MUTEX_ALL_ACCESS);
		if(!mut)
			throw L5Exception("Can't initialize time queue");
		LARGE_INTEGER p, op;
		DWORD dw, writtenBytes;

		regFilehandle = CreateFileA(pathToRegMomsFile.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if(regFilehandle == INVALID_HANDLE_VALUE)
			throw L5Exception("Can't initialize time queue");
		p.QuadPart = 0;
		if(!SetFilePointerEx(regFilehandle, p, &op, FILE_END))
				throw L5Exception("Can't initialize time queue");
		if(op.QuadPart != 0){
			p.QuadPart = 0;
			if(!SetFilePointerEx(regFilehandle, p, &op, FILE_BEGIN))
				throw L5Exception("Can't initialize time queue");
			int blockSize = 250000;
			TIME_QUEUE_REGISTER_ROW* rows = new TIME_QUEUE_REGISTER_ROW[blockSize];
			if(!rows)
				throw L5Exception("Can't initialize time queue");
			TIME_QUEUE_REGISTER_ROW_POINTER pi;
			memset(&pi, 0, sizeof pi);
			DWORD dw;
			unsigned int prevMom = 0;
			int count = 0;
			do{
				if(!ReadFile(regFilehandle, rows, sizeof(TIME_QUEUE_REGISTER_ROW) * blockSize , &dw, NULL))
					throw L5Exception("Can't initialize time queue");
				int readBytes = dw / sizeof(TIME_QUEUE_REGISTER_ROW);
				for(int k = 0; k < readBytes; k++){
					if(rows[k].moment - prevMom >= 150){
						prevMom = rows[k].moment;
						pi.moment = rows[k].moment;
						pi.pos = count * sizeof(TIME_QUEUE_REGISTER_ROW);
						rrpointers.push_back(pi);
					}
					count++;
				}
			}while(dw >= blockSize * sizeof(TIME_QUEUE_REGISTER_ROW));
			registeredMomentsNum = count;
			delete [] rows;
		}
};

TIME_QUEUE::~TIME_QUEUE(){
	Block();

	
	ClearBuffOfRegisteredMoments();

	CloseHandle(mut);
	CloseHandle(filehandle);
	CloseHandle(regFilehandle);
};

bool TIME_QUEUE::Block(){
	if(WaitForSingleObject(mut, INFINITE) == WAIT_FAILED)
		return false;
	else
		return true;
};

bool TIME_QUEUE::Free(){
	return ReleaseMutex(mut);
};

bool TIME_QUEUE::GetBlockInFinding(int index, TIME_QUEUE_REGISTER_ROW_POINTER& out, bool with_loaded){
	LARGE_INTEGER st,en,p;
	DWORD dw, wrBytes;
	int len = rrpointers.size();
	if(!with_loaded && rrpointers[index].only_load)
	{
		out = rrpointers[index];
		return true;
	}
	
	if(!rrpointers[index].block || index == len - 1){
		Block();

		st.QuadPart = rrpointers[index].pos;
		if(index != len - 1)
			en.QuadPart = rrpointers[index + 1].pos;
		else{
			p.QuadPart = 0;
			if(!SetFilePointerEx(regFilehandle, p, &en, FILE_END)){
				Free();
				return false;	
			}
		}

		out = rrpointers[index];
		int blockSize = (en.QuadPart - st.QuadPart) /  sizeof(TIME_QUEUE_REGISTER_ROW);
		
		if(blockSize == 0)
		{
			Free();
			return true;
		}
		
		TIME_QUEUE_REGISTER_ROW* block = new TIME_QUEUE_REGISTER_ROW[blockSize];
		if(!block){
			std::cout << ("Can't allocate memory in finding of packets in area") << std::endl;
			Free();
			return false;
		}

		if(!SetFilePointerEx(regFilehandle, st, &p, FILE_BEGIN)){
				Free();
				return false;	
		}

		if(!ReadFile(regFilehandle, block, blockSize * sizeof(TIME_QUEUE_REGISTER_ROW), &dw, NULL)){
				Free();
				return false;
		}

		blocksSize += dw;

		blockSize = dw / sizeof(TIME_QUEUE_REGISTER_ROW);
		if(blockSize == 0)
		{
			Free();
			return true;
		}
		
		if(rrpointers[index].block){
			blocksSize -= rrpointers[index].blockSize * sizeof(TIME_QUEUE_REGISTER_ROW);
			delete [] rrpointers[index].block;
		}
		rrpointers[index].block = block;
		rrpointers[index].blockSize = blockSize;

		if(rrpointers[index].only_load)
		{
			out = rrpointers[index];
			return true;
		}

		//finding of maximal price
		float maxInBuyInputSignal = 0;
		float maxInSellInputSignal = MAXDWORD;
		int posForSell = -1;
		int posForBuy = -1;
		for(int k = 0; k < blockSize; k++){
				if(block[k].signalType == SELL_SIGNAL && block[k].price > maxInBuyInputSignal){
					maxInBuyInputSignal=block[k].price;
					posForSell = k;
				}

				if(block[k].signalType == BUY_SIGNAL && block[k].price < maxInSellInputSignal){
					maxInSellInputSignal=block[k].price;
					posForBuy = k;
				}
		}
		rrpointers[index].posOfMaxForBuyReq = posForBuy;
		rrpointers[index].posOfMaxForSellReq = posForSell;
		if(posForBuy != -1){
			rrpointers[index].momentForBuyReq = block[posForBuy].moment;
			rrpointers[index].priceForBuyReq = block[posForBuy].price;
		}
		else{
			rrpointers[index].priceForBuyReq = MAXDWORD;
		}

		if(posForSell != -1){
			rrpointers[index].momentForSellReq = block[posForSell].moment;
			rrpointers[index].priceForSellReq = block[posForSell].price;
		}
		else{
			rrpointers[index].priceForSellReq = 0;
		}

		rrpointers[index].start_moment = block[0].moment;
		if(index != len - 1)
			rrpointers[index].only_load = true;

		Free(); 
	}
	
	out = rrpointers[index];
	if(blocksSize > 10000000){
		int count = 0;
		for(int i = 0; i < len; i++){
			if(rrpointers[i].block && i != index)
			{
				blocksSize -= rrpointers[i].blockSize * sizeof(TIME_QUEUE_REGISTER_ROW);
				rrpointers[i].blockSize = 0;
				delete [] rrpointers[i].block;
				rrpointers[i].block = 0;
				if(count++ > 7)
					break;
			}
		}
	}

	return true;
}


bool TIME_QUEUE::FindPacketsInArea(unsigned int start_time, unsigned int end_time, float start_price, char requiredSignalType, ulong&outmd5p1, ulong&outmd5p2, float& efficency, unsigned int& outmoment){
	bool requiredReading = true;
	if(start_time == prevStartMomentInFinding && end_time == prevLastMomentInFinding){
		requiredReading = false;
	}

	int len = rrpointers.size();
	if(!len)
	{
		outmoment = 0;
		return true;
	}

	if(requiredReading){
		int stP = 0, lastP = 0;
		bool f1 = false, f2 = false;
		
		for(int i = 0; i < len; i++){
			if(!f1 && i != len-1 && rrpointers[i].moment <= start_time && rrpointers[i + 1].moment > start_time){
				stP = i;
				f1 = true;
			}
			else if(!f1 && i == len - 1){
				stP = i;
				f1 = true;
			}

			if(!f2 && i != len-1 && rrpointers[i].moment <= end_time && rrpointers[i + 1].moment > end_time){
				lastP = i;
				f2 = true;
			}
			else if(!f2 && i == len - 1){
				lastP = i;
				f2 = true;
			}
			if(f1 && f2)
				break;
		}
		lastP++;

		//finding of maximal price
		float maxInBuyInputSignal = 0;
		float maxInSellInputSignal = MAXDWORD;
		int blockPosForSell = -1;
		int blockPosForBuy = -1;
		int posInBlockForSell = -1;
		int posInBlockForBuy = -1;
		TIME_QUEUE_REGISTER_ROW_POINTER data;
		TIME_QUEUE_REGISTER_ROW_POINTER frontData;

		for(int i = stP; i < lastP; i++){
			if(!GetBlockInFinding(i, data)){
				return false;
			}

			float buyPrice = data.priceForSellReq;
			float sellPrice = data.priceForBuyReq;
			
			if(buyPrice > maxInBuyInputSignal){
				if(data.momentForSellReq < start_time)
					if(i != lastP - 1 && !GetBlockInFinding(i + 1, frontData))
						return false;

				if(((data.momentForSellReq < start_time && (i == lastP - 1 || frontData.momentForSellReq > start_time)) ||
					(data.momentForSellReq > end_time && (data.start_moment <= end_time)))
						){ 
						//loop into the block
						if(!GetBlockInFinding(i, data, true)){
							return false;
						}

						TIME_QUEUE_REGISTER_ROW* block = data.block;
						int blockSize = data.blockSize;
						float maxInBuyInputSignal2 = 0;
						unsigned int momentForSellReq2 = 0;
						int posInBlockForSell2 = -1;
						for(int k = 0; k < blockSize; k++){
							if(block[k].signalType == SELL_SIGNAL && block[k].moment >= start_time && block[k].moment <= end_time){
								if(block[k].price > maxInBuyInputSignal2){
									maxInBuyInputSignal2=block[k].price;
									posInBlockForSell2 = k;
									momentForSellReq2 = block[k].moment;
								}
							}
						}

						if(maxInBuyInputSignal2 > maxInBuyInputSignal){
							maxInBuyInputSignal = maxInBuyInputSignal2;
							blockPosForSell = i;
							posInBlockForSell = posInBlockForSell2;
						}
				}
				else if(data.momentForSellReq > start_time && data.momentForSellReq <= end_time){
					maxInBuyInputSignal=buyPrice;
					blockPosForSell = i;
					posInBlockForSell = data.posOfMaxForSellReq;
				}
			}
			
			if(sellPrice < maxInSellInputSignal){
				if(data.momentForBuyReq < start_time)
					if(i != lastP - 1 && !GetBlockInFinding(i + 1, frontData))
						return false;

				if(((data.momentForBuyReq < start_time && (i == lastP - 1 || frontData.momentForBuyReq > start_time)) ||
					(data.momentForBuyReq > end_time && (data.start_moment <= end_time)))
						){ 
						//loop into the block
						if(!GetBlockInFinding(i, data, true)){
							return false;
						}

						TIME_QUEUE_REGISTER_ROW* block = data.block;
						int blockSize = data.blockSize;
						float maxInSellInputSignal2 = 0;
						unsigned int momentForBuyReq2 = 0;
						int posInBlockForBuy2 = -1;
						for(int k = 0; k < blockSize; k++){
							if(block[k].signalType == BUY_SIGNAL && block[k].moment >= start_time && block[k].moment <= end_time){
								if(block[k].price < maxInSellInputSignal2){
									maxInSellInputSignal2=block[k].price;
									posInBlockForBuy2 = k;
									momentForBuyReq2 = block[k].moment;
								}
							}
						}

						if(maxInSellInputSignal2 > maxInSellInputSignal){
							maxInSellInputSignal = maxInSellInputSignal2;
							blockPosForBuy = i;
							posInBlockForBuy = posInBlockForBuy2;
						}
				}
				else if(data.momentForBuyReq > start_time && data.momentForBuyReq <= end_time){
					maxInSellInputSignal=sellPrice;
					blockPosForBuy = i;
					posInBlockForBuy = data.posOfMaxForBuyReq;
				}
			}
		}

		prevBlockIndexForSellReq = blockPosForSell;
		prevBlockIndexForBuyReq = blockPosForBuy;
		prevPosInBlockForSellReq = posInBlockForSell;
		prevPosInBlockForBuyReq = posInBlockForBuy;
	}
	
	prevStartMomentInFinding = start_time; 
	prevLastMomentInFinding = end_time;
	int blockPos = requiredSignalType == SELL_SIGNAL?prevBlockIndexForSellReq:prevBlockIndexForBuyReq;
	int pos = requiredSignalType == SELL_SIGNAL?prevPosInBlockForSellReq:prevPosInBlockForBuyReq;

	if(pos == -1){
		outmoment = 0;
		return true;
	}

	TIME_QUEUE_REGISTER_ROW_POINTER data;
	if(!GetBlockInFinding(blockPos, data, true)){
		return false;
	}
	if(data.block[pos].moment > start_time && data.block[pos].moment <= end_time)
	{
		outmd5p1 = data.block[pos].md5p1;
		outmd5p2 = data.block[pos].md5p2;
		outmoment = data.block[pos].moment;
		efficency = data.block[pos].signalType == BUY_SIGNAL?start_price - data.block[pos].price:data.block[pos].price - start_price;
	}
	else
		outmoment = 0;

	return true;
}

void TIME_QUEUE::ClearBuffOfRegisteredMoments(){
	for(int i = 0; i < rrpointers.size(); i++){
		if(rrpointers[i].block)
		{
			blocksSize -= rrpointers[i].blockSize * sizeof(TIME_QUEUE_REGISTER_ROW);
			rrpointers[i].blockSize = 0;
			delete [] rrpointers[i].block;
			rrpointers[i].block = 0;
		}
	}
};

int _tmain(int argc, _TCHAR* argv[])
{
	for(;;){
			std::cout << "Initialization . . . " << std::endl;
			TIME_QUEUE timeQueue;
			MYSQL* dbH = mysql_init(NULL);
			if(!dbH)
			{
				std::cout << "Error in connection of database" << std::endl;
				break;
			};
			bool reconnect = true;
			mysql_options(dbH, MYSQL_OPT_RECONNECT, &reconnect);
			dbH = mysql_real_connect(dbH, "localhost", "root", "", "l5_database", 0, NULL, 0);
			if(!dbH){
				std::cout << "Error in connection of database" << std::endl;
				break;
			}

			std::stringstream  query;
			query << "SET net_read_timeout = 1800"; 
			mysql_query(dbH, query.str().c_str());
			query.str("");
			query << "SET net_write_timeout = 1800";
			mysql_query(dbH, query.str().c_str());
			query.str("");

			HANDLE handle = CreateFileA(pathToMomsForRes.c_str(), GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
			if(!handle)
			{
				std::cout << "Error in opening file" << std::endl;
				break;
			}
			LARGE_INTEGER l, op;
			l.QuadPart = 0;
			if(!SetFilePointerEx(handle, l, &op, FILE_END)){
				std::cout << "Error in setting of position in file" << std::endl;
				break;
			}
			if(!SetFilePointerEx(handle, l, NULL, FILE_BEGIN)){
				std::cout << "Error in setting of position in file" << std::endl;
				break;
			}

			ulong size = op.QuadPart / sizeof(MOMENTS_FOR_RES_ROW);
			int buff_size = 20000;
			MOMENTS_FOR_RES_ROW* moments = new MOMENTS_FOR_RES_ROW[buff_size];
			FOR_CONSOLE_CHECKING* existingForStorage;
			FOR_CONSOLE_RESOLVING* storageForConsole;
			ulong signalsForResolving = size;
			existingForStorage = new FOR_CONSOLE_CHECKING[signalsForResolving];
			storageForConsole = new FOR_CONSOLE_RESOLVING[signalsForResolving];
			memset(existingForStorage, 0, signalsForResolving * sizeof (FOR_CONSOLE_CHECKING));
			memset(storageForConsole, 0, signalsForResolving * sizeof(FOR_CONSOLE_RESOLVING));

			std::stringstream gquery;
			gquery << "CREATE TABLE IF NOT EXISTS " + l5Symbol + "_optimizer_results_of_week ( "
			   << "inmd5p1 varchar(50) NOT NULL, "
			   << "inmd5p2 varchar(50) NOT NULL, "
			   << "outmd5p1 varchar(50) NOT NULL, "
			   << "outmd5p2 varchar(50) NOT NULL, " 
			   << "efficency double NOT NULL, "
			   << "all_duration int(11) NOT NULL, "
			   << "deals int(11) NOT NULL, " 
			   << "average_signal int(11) NOT NULL"
			   << ") ENGINE=MYISAM DEFAULT CHARSET=cp1251;";

			if(mysql_query(dbH, gquery.str().c_str())){
				std::cout << ("Error in resolving thread: error in creating of table: " + string(mysql_error(dbH))) << std::endl;
				break;
			}
			gquery.str("");


			std::cout << "Initialazation has been completed! rows in file: " << signalsForResolving << std::endl;

			ulong commonCount = 0;
			for(ulong j = 0; j < size;){
				int read_bytes;
				DWORD dw;
				if(!ReadFile(handle, moments, buff_size * sizeof(MOMENTS_FOR_RES_ROW), &dw, NULL)){
					std::cout << "error in reading" << std::endl;
					break;
				}
				read_bytes = dw;
				int read_rows = read_bytes / sizeof(MOMENTS_FOR_RES_ROW);
				j+=read_rows;
	
				ulong s = time(NULL);
				for(int i = 0; i < read_rows; i++){

					ulong hashKey1 = ((moments[i].md5p1  ^  moments[i].md5p2)  +  moments[i].start_moment) % signalsForResolving;
					int iterations1 = 0;
					while(existingForStorage[hashKey1].md5p1 != moments[i].md5p1){
						if(existingForStorage[hashKey1].md5p1 == 0)
						{
							existingForStorage[hashKey1].md5p1 = moments[i].md5p1;
							break;
						}

						hashKey1++;
						if(hashKey1 >= signalsForResolving){
							hashKey1 = 0;
							iterations1++;
							if(iterations1 > 1)
							{
								std::cout << "In infinite in finding of row" << std::endl;
								break;
							}
						}
					}
					existingForStorage[hashKey1].num++;

					if(existingForStorage[hashKey1].num > 1)
					{
						continue;
					}
					ulong outmd5p2, outmd5p1;
					unsigned int outmoment = 0;
					float efficency = 0;

					if(!timeQueue.FindPacketsInArea(moments[i].start_moment, moments[i].end_moment, moments[i].start_price, moments[i].signalType == BUY_SIGNAL?SELL_SIGNAL:BUY_SIGNAL, outmd5p1, outmd5p2, efficency, outmoment)){
						std::cout << ("Error in resolving thread: can't find packets in area") << std::endl;
						continue;
					}

					if(outmoment){
						if(efficency <= 0)
							efficency = -0.0030;
						ulong hashKey2 = ((moments[i].md5p1  ^  outmd5p1)  +  ((moments[i].md5p2  ^  outmd5p2) >> 24)) % signalsForResolving;
						int iterations = 0;
						while(storageForConsole[hashKey2].inmd5p1 != moments[i].md5p1 || storageForConsole[hashKey2].inmd5p2 != moments[i].md5p2 || storageForConsole[hashKey2].outmd5p1 != outmd5p1 || storageForConsole[hashKey2].outmd5p2 != outmd5p2){
					
							if(storageForConsole[hashKey2].inmd5p1 == 0 && storageForConsole[hashKey2].inmd5p2 == 0){
								storageForConsole[hashKey2].inmd5p1 = moments[i].md5p1;
								storageForConsole[hashKey2].inmd5p2 = moments[i].md5p2;
								storageForConsole[hashKey2].outmd5p1 = outmd5p1;
								storageForConsole[hashKey2].outmd5p2 = outmd5p2;
								break;
							}

							hashKey2++;
							if(hashKey2 >= signalsForResolving){
								hashKey2 = 0;
								iterations++;
								if(iterations > 1)
								{
									std::cout << "In infinite in finding of row" << std::endl;
									break;
								}
							}
						}
						
						//setting
						if(iterations < 2){
							storageForConsole[hashKey2].deals++;
							float* prevEff = storageForConsole[hashKey2].eff;
							unsigned int* prevSt = storageForConsole[hashKey2].st_moms;
							unsigned int* prevMo = storageForConsole[hashKey2].outmoms;
							char* prevS = storageForConsole[hashKey2].signals;

							storageForConsole[hashKey2].eff = new float[storageForConsole[hashKey2].deals];
							storageForConsole[hashKey2].st_moms = new unsigned int[storageForConsole[hashKey2].deals];
							storageForConsole[hashKey2].outmoms = new unsigned int[storageForConsole[hashKey2].deals];
							storageForConsole[hashKey2].signals = new char[storageForConsole[hashKey2].deals];
							
							for(int k = 0; k < storageForConsole[hashKey2].deals - 1; k++)
							{
								storageForConsole[hashKey2].eff[k] = prevEff[k];
								storageForConsole[hashKey2].st_moms[k] = prevSt[k];
								storageForConsole[hashKey2].outmoms[k] = prevMo[k];
								storageForConsole[hashKey2].signals[k] = prevS[k];
							}
							delete [] prevEff;
							delete [] prevMo;
							delete [] prevSt;
							delete [] prevS;

							storageForConsole[hashKey2].eff[storageForConsole[hashKey2].deals - 1] = efficency;
							storageForConsole[hashKey2].st_moms[storageForConsole[hashKey2].deals - 1] = moments[i].start_moment;
							storageForConsole[hashKey2].outmoms[storageForConsole[hashKey2].deals - 1] = outmoment;
							storageForConsole[hashKey2].signals[storageForConsole[hashKey2].deals - 1] = moments[i].signalType == BUY_SIGNAL?1:-1;
							
							commonCount++;
						}
					}
				}

				std::cout << "rows processed: " << read_bytes / sizeof(MOMENTS_FOR_RES_ROW) << " for " << (time(NULL) - s) << "sec; sorted: " << commonCount << std::endl;
				s = time(NULL);
				
			}

			std::cout << "SORTING COMPLETED!!! WRITING . . ." << std::endl;
			ulong duplicates = 0;
			ulong allduplicates = 0;
			ulong written_rows = 0;
			ulong incoming_positions = 0;
			ulong accounted_positions = 0;
			for(int i = 0; i < signalsForResolving; i++){
				if(existingForStorage[i].md5p1 != 0){
					int dup = existingForStorage[i].num;
					if(dup > 1){
						duplicates++;
						allduplicates += (dup - 1);
					}
				}

				if(storageForConsole[i].inmd5p1 != 0 || storageForConsole[i].inmd5p2 != 0){
					float efficency = 0;
					int deals = 0;
					ulong all_duration = 0;
					int average_signal = 0;

					std::vector<bool> dels;
					for(int l = 0; l < storageForConsole[i].deals; l++)
						dels.push_back(false);
					int len = dels.size();
					int min_startmoment;
					int posj;
						for(int l = 0; l < len; l++){
							if(!dels[l]){
								min_startmoment = storageForConsole[i].st_moms[l];
								posj = l;
								dels[l] = true;
								for(int k = l + 1; k < len; k++){
									if(!dels[k] && storageForConsole[i].outmoms[l] == storageForConsole[i].outmoms[k]){
										dels[k] = true;
										if(min_startmoment > storageForConsole[i].st_moms[k]){
											posj = k;
											min_startmoment = storageForConsole[i].st_moms[k];
										}
									}
								}

								deals++;
								efficency += storageForConsole[i].eff[posj];
								average_signal += storageForConsole[i].signals[posj];
								all_duration += (storageForConsole[i].outmoms[posj] - storageForConsole[i].st_moms[posj]);
							}
						}
					 
					written_rows++;
					accounted_positions += deals;
					incoming_positions += (storageForConsole[i].deals - deals);

					//writing
					query << "INSERT INTO " + l5Symbol + "_optimizer_results_of_week (inmd5p1 , inmd5p2, outmd5p1, outmd5p2, efficency, all_duration, deals, average_signal) VALUES (" 
							<< storageForConsole[i].inmd5p1 << ", " << storageForConsole[i].inmd5p2 <<  ", " << storageForConsole[i].outmd5p1 << ", " << storageForConsole[i].outmd5p2 << ", " << efficency << ", " << all_duration << ", " << deals << ", " <<  (int) (average_signal) << " ) ";
					
					if(mysql_query(dbH, query.str().c_str())){
							std::cout << ("Error in resolving thread: error in inserting into database: " + string(mysql_error(dbH))) << std::endl;
							continue;
					}
					query.str("");

					delete [] storageForConsole[i].eff;
					delete [] storageForConsole[i].st_moms;
					delete [] storageForConsole[i].signals;
					delete [] storageForConsole[i].outmoms;
					if(written_rows % 100000 == 0)
						std::cout << "rows written: " << written_rows << std::endl;
				}
			}

			std::cout << "RESOLVING HAS BEEN SUCCESSFULLY COMPLETED!!!" << std::endl;
			std::cout << "rows_written: " << written_rows << "; duplicated rows: " << duplicates << "; all duplicates: " << allduplicates << std::endl;
			std::cout << "accounted_positions: " << accounted_positions << "; once positions: " << incoming_positions << std::endl;

			delete [] existingForStorage;
			delete [] storageForConsole;

			CloseHandle(handle);
			break;
	}

	char buff[100];
	std::cin >> buff;

	return 0;
}

