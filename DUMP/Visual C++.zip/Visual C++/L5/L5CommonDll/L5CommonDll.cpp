/*
 * L5CommondDll - set of functions for L5 System
 * Author: Tim Jackson <tim.jackson.mailbox@gmail.com>
 * Copyright, 2014. All rights reserved
 */

#include "stdafx.h"

#define MT4_EXPFUNC __declspec(dllexport)

#include "Poco/RegularExpression.h"
#include "Poco/DigestEngine.h"
#include "Poco/MD5Engine.h"
#include "Poco/Path.h"
#include "Poco/File.h"
#include "Poco/Exception.h"
#include "Poco/UnicodeConverter.h"
#include "Poco/Random.h"
#include "Poco/DateTime.h"
#include "Poco/DateTimeFormatter.h"
#include "Poco/NumberParser.h"
#include "Poco/Logger.h"
#include "Poco/FileChannel.h"
#include "Poco/AutoPtr.h"
#include "Poco/FormattingChannel.h"
#include "Poco/PatternFormatter.h"
#include "Poco/Glob.h"

#include <string>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <set>
#include <iterator>

#include <cstdio>
#include <Windows.h>


#include "mysql.h"

typedef unsigned __int64 ulong;
typedef std::string string;

Poco::Path storageDirectory;
string l5Symbol;

bool is_deinitialization = false;
bool is_stopping_rthread = false;
bool is_initialization = false;

wchar_t* ToUTF8(std::string arg){
	int len = arg.length();
	wchar_t* result = NULL;
	if(len != 0){
		result = new wchar_t[len + 1]; //Important!!! Don't forget delete the pointer
		result[len] = 0;
		MultiByteToWideChar(CP_ACP, 0, arg.c_str(), len, result, len);
	};
	return result;
};

char* ToASCII(std::wstring arg){
	int len = arg.length();
	char* result = NULL;
	if(len != 0){
		result = new char[len + 1]; //Important!!! Don't forget delete the pointer
		result[len] = 0;
		WideCharToMultiByte(CP_ACP, 0, arg.c_str(), len, result, len, NULL, NULL);
	}
	return result;
};

std::vector<std::string> explode(std::string const & s, char delim)
{
    std::vector<std::string> result;
    std::istringstream iss(s);

    for (std::string token; std::getline(iss, token, delim); )
    {
        result.push_back(std::move(token));
    }

    return result;
}

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+

MT4_EXPFUNC int __stdcall mql4_preg_match(wchar_t* wpattern, wchar_t* wstring, int* start_pockets_pos, int* pockets_lengths, int start_pos){	//important: start_pockets_pos' and pockets_lengths' length is 1000
	int size = 0;
	if(!wpattern || !wstring)
		return size;
	
	char* pPattern = ToASCII(wpattern);
	char* pString = ToASCII(wstring);
	std::string pattern = pPattern;
	std::string string = pString;
	if(pattern == "" || string == "")
		return 0;
	
	Poco::RegularExpression reg(pattern);
	Poco::RegularExpression::MatchVec posVec;
	if(size = reg.match(string, start_pos, posVec)){
		int limit = 1000;
		int count = 0;
		for(int i = 0; i < size; i++){
			start_pockets_pos[i] = posVec[i].offset;
			pockets_lengths[i] = posVec[i].length;  
			if(count++ >= limit)
			{
				size = limit;
				break;
			}
		};
	}

	delete [] pPattern;
	delete [] pString;

	return size;
}

MT4_EXPFUNC bool mql4_md5_hash(wchar_t* msg, char* result){
	bool res = true;
	char* pMsg = ToASCII(msg);
	std::string message = pMsg;
	
	std::string hash = "d41d8cd98f00b204e9800998ecf8427e";
	if(message != ""){
		Poco::MD5Engine md5;
		md5.update(message);
		const Poco::DigestEngine::Digest& digest = md5.digest();
		std::string md5string = Poco::DigestEngine::digestToHex(digest);
		hash = md5string;
	}
	for(int i = 0; i < 32; i++)
		result[i] = hash[i];


	delete [] pMsg;
	return res;
};


MT4_EXPFUNC ulong mql4_get_timestamp(bool milliseconds = false){
	Poco::DateTime now;
	ulong timestamp = now.timestamp().epochTime();
	if(milliseconds)
		timestamp = timestamp*1000 + now.millisecond();
	return timestamp;
};

MT4_EXPFUNC ulong mql4_md5_part(const char* md5S, bool is_second){
	string md5 = md5S;
	if(!is_second)
		return Poco::NumberParser::parseHex64(md5.substr(0, 16));
	else
		return Poco::NumberParser::parseHex64(md5.substr(16, 16));
};

bool loggerInitialized = false;
void write_in_log(string &msg){
	if(!is_initialization)
		return;

	string pName = "log_file.log";
	Poco::Path path(storageDirectory);
	path.append(pName);
	Poco::File file(path);
	FILE* handle = fopen(path.toString().c_str(), "a+");
	if(!handle)
		return;
	
	Poco::DateTime now;
	char buff[1000];
	string rmsg = "[" + string(itoa(now.year(), buff, 10)) + "-" + string(itoa(now.month(), buff, 10)) + "-" + string(itoa(now.day(), buff, 10)) + " " 
			+ string(itoa(now.hour(), buff, 10)) + ":" + string(itoa(now.minute(), buff, 10)) + ":" + string(itoa(now.second(), buff, 10)) + "]";
	rmsg = rmsg + " " + msg + "\n";
	fwrite(rmsg.c_str(), rmsg.length(), 1, handle);
	fclose(handle);
}

MT4_EXPFUNC void mql4_log(wchar_t *amsg){
	char* p = ToASCII(amsg);
	std::string mSg = p?p:"";
	delete[] p;
	write_in_log("###OPTIMIZER_OF_INDICATORS - MQL4_FUNCTIONALITY### " + mSg);
}

void opLog(string msg){
	write_in_log("###OPTIMIZER_OF_INDICATORS - INNER FUNCTIONS###  " + msg); 
};

class L5Exception : public std::exception {
  public:
	  L5Exception(string msg){
		  opLog("!!!CRITICAL ERROR!!! " + msg);
		  MessageBoxA(0, msg.c_str(), "L5 System ERROR", MB_ICONERROR | MB_OK);
	  }
};

/*
 * FOR RESOLVING GAINS
 */

//FHASH TABLE CLASS
const int size_step = 6666666;
const int maxPacketTableSize = MAXDWORD;
const int minPacketTableSize = 6666666;
const int sizeOfPacketTableCache = 10000000;
const int regMomGranularity = 166;
const int maxSizeForIndecesInOptimizerSolutions = 666;
const int maximalBufferSizeForFindingOfSuitablePackets = 26214400;
const int minDealsForSelectingByCriterion = 3;
const int intervalForGettingSolutions = 3600 * 2;
const int minimalDurationForPostions = 3*60;
const int selectingLimitInMonthProcessing = 6666666;

HANDLE rThread;
HANDLE mutOfWeekendProcessing = 0;

MYSQL* dbH = NULL;
MYSQL* dbRH = NULL;
bool is_in_weekend_processing = false;

float optimalProfitForPositions = 0.0010;
unsigned int optimalDurationForQuickPositions = 60*25;
ulong definedPacketTableStartingSize = size_step;
int numOfSelectedSolutions = 601;
int numRowsWithSameOutPacketInSolutions = 3;

struct PACKET_TABLE_META_DATA {
	ulong size;
	int num_collisions;
	ulong rows_written;
	char sign[33];
	bool Write(string tableName){
		string pName = "packet_table_meta_data_of_" + tableName + ".dat";
		Poco::Path path(storageDirectory);
		path.append(pName);
		Poco::File file(path);
		if(!file.exists())
			file.createFile();
		FILE* fp = fopen(path.toString().c_str(), "w+b");
		
		if(fp){
			/*
			Poco::MD5Engine md5;
			md5.update(tableName);
			const Poco::DigestEngine::Digest& digest = md5.digest();
			std::string md5string = Poco::DigestEngine::digestToHex(digest);
			strcpy(sign, md5string.c_str());
			sign[32] = 0;
			*/
			if(!fwrite(this, sizeof *this, 1, fp))
				return false;

			fclose(fp);

		}
		else{
			return false;
		}

		return true;
	}
	bool Get(string tableName){
		string pName = "packet_table_meta_data_of_" + tableName + ".dat";
		Poco::Path path(storageDirectory);
		path.append(pName);
		Poco::File file(path);
		if(!file.exists())
			return false;
		FILE* fp = fopen(path.toString().c_str(), "r+b");
		if(fp){
			if(!fread(this, sizeof *this, 1, fp))
				return false;
			fclose(fp);
		}
		else{
			return false;
		}
		
		/*Poco::MD5Engine md5;
		md5.update(tableName);
		const Poco::DigestEngine::Digest& digest = md5.digest();
		std::string md5string = Poco::DigestEngine::digestToHex(digest);
		std::string sSign = sign;
		if(md5string != sign)
			return false;
		*/
		return true;
	}
};

template<class T>
class PACKET_TABLE_ROW{
	public:
		ulong md5p1;
		ulong md5p2;
		ulong next_pos;
		T val;
};

template<class T>
class PACKET_TABLE_ROW_CACHE{
	public:
		ulong pos;
		HANDLE fp;
		bool is_exists;
		T row;
};

template<class T>
class PACKET_TABLE{
	private:
		string name;
		HANDLE handles[2];
		HANDLE mut;
		PACKET_TABLE_ROW<T>* mt;
		PACKET_TABLE_ROW<T>* mc;
		bool use_memory;

		int max_collisions;
		ulong hash(ulong md5p1, ulong md5p2);
		int hash_for_cache(ulong md5p1, ulong md5p2);
		bool Initial(ulong starting_size = size_step, bool yet_ready = false);
		bool is_in_resizing;
		ulong posForeach;
		int handleForeach;
		PACKET_TABLE_ROW<T>* bufferForeach;
		int sizeOfBufferForeach;
		int countInBufferForeach;

		PACKET_TABLE_ROW_CACHE<PACKET_TABLE_ROW<T>>* cache;
		int cacheSize;

		bool Block();
		bool Free();

	public:
		PACKET_TABLE_META_DATA meta;

		PACKET_TABLE(std::string name, ulong starting_size = size_step, bool is_in_res = false, bool use_memory = false);
		~PACKET_TABLE();
		bool Get(ulong md5p1, ulong md5p2, T* out, HANDLE *outfp = NULL, ulong* outpos = NULL, PACKET_TABLE_ROW<T> *outrow = NULL, bool* is_exists = NULL);
		bool Set(ulong md5p1, ulong md5p2, T* val, bool* is_exists = NULL);
		bool ResizeTable(int newSize);
		bool Delete(ulong md5p1, ulong md5p2);
		bool Next(ulong& md5p1, ulong& md5p2, T* out);
		void ResetForeach(){
			posForeach = handleForeach = countInBufferForeach =  0;
		}
		bool TableFlush();
		
};

template<class T>
PACKET_TABLE<T>::PACKET_TABLE(std::string arg, ulong starting_size, bool is_in_res, bool ause_memory = false){
	name = arg;
	max_collisions = 200;
	is_in_resizing = is_in_res;

	bufferForeach = 0;
	sizeOfBufferForeach = 0;
	ResetForeach();
	use_memory = ause_memory;

	memset(&handles, 0, sizeof handles);
	if(!Initial(starting_size))
		throw L5Exception("Can't initial packet table");
};

template<class T>
bool PACKET_TABLE<T>::TableFlush(){
	bool res = true;
	for(int i = 0; i < 2; i++)
		res &= FlushFileBuffers(handles[i]);
	return res;
}

template<class T>
bool PACKET_TABLE<T>::Initial(ulong starting_size, bool yet_ready){
	if(!meta.Get(name) || meta.size == 0){
		if(yet_ready)
			return false;
		memset(&meta, 0, sizeof meta);
		meta.size = starting_size;
		
	}
	else{
		yet_ready = true;
	}
	max_collisions = (meta.size / 100) * 13;
	cacheSize = sizeOfPacketTableCache / sizeof(PACKET_TABLE_ROW_CACHE<PACKET_TABLE_ROW<T>>);
	cache = new PACKET_TABLE_ROW_CACHE<PACKET_TABLE_ROW<T>>[cacheSize];
	if(!cache)
		return false;
	memset(cache, 0, cacheSize * sizeof(PACKET_TABLE_ROW_CACHE<PACKET_TABLE_ROW<T>>));

	//opening of files;
	string pName = "packet_table_collision_data_of_" + name + ".dat";
	Poco::Path path(storageDirectory);
	path.append(pName);
	Poco::File file(path);
	if(!file.exists())
		file.createFile();
	std::wstring wpath;
	Poco::UnicodeConverter::toUTF16(path.toString(), wpath);
	handles[0] = CreateFileW(wpath.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(handles[0] == INVALID_HANDLE_VALUE)
		return false;
	if(!yet_ready){
		LARGE_INTEGER l;
		l.QuadPart = (ulong) max_collisions * sizeof PACKET_TABLE_ROW<T>;
		if(!SetFilePointerEx(handles[0], l, NULL, FILE_BEGIN))
			return false;
		else if(!SetEndOfFile(handles[0]))
			return false;
		else{
				l.QuadPart = 0;
				if(SetFilePointerEx(handles[0], l, NULL, FILE_BEGIN)){
					int step = 10000000;
					char* buff = new char[step];
					memset(buff, 0, step);
					ulong size = (ulong) max_collisions * sizeof PACKET_TABLE_ROW<T>;
					ulong written_bytes = 0;
					while(written_bytes < size){
						DWORD wrBytes;
						step = (size - written_bytes < step)?size - written_bytes:step;
						if(!WriteFile(handles[0], buff, step, &wrBytes, NULL))
							return false;
						written_bytes += wrBytes;
					}
					delete [] buff;
				}
				else
					return false;
		}
	}

	{
		 pName = "packet_table_data_of_" + name + ".dat";
		 Poco::Path path(storageDirectory);
		 path.append(pName);
		 Poco::File file(path);
		 if(!file.exists())
			file.createFile();
		std::wstring wpath;
		Poco::UnicodeConverter::toUTF16(path.toString(), wpath);
		handles[1] = CreateFileW(wpath.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if(handles[1] == INVALID_HANDLE_VALUE)
			return false;
		if(!yet_ready){
			LARGE_INTEGER l;
			l.QuadPart = (ulong) meta.size * sizeof PACKET_TABLE_ROW<T>;
			if(!SetFilePointerEx(handles[1], l, NULL, FILE_BEGIN))
				return false;
			else if(!SetEndOfFile(handles[1]))
				return false;
			else{
				l.QuadPart = 0;
				if(SetFilePointerEx(handles[1], l, NULL, FILE_BEGIN)){
					int step = 10000000;
					char* buff = new char[step];
					memset(buff, 0, step);
					ulong size = meta.size * sizeof PACKET_TABLE_ROW<T>;
					ulong written_bytes = 0;
					while(written_bytes < size){
						DWORD wrBytes;
						step = (size - written_bytes < step)?size - written_bytes:step;
						if(!WriteFile(handles[1], buff, step, &wrBytes, NULL))
							return false;
						written_bytes += wrBytes;
					}
					delete [] buff;
				}
				else
					return false;
			}
		}
	}

	mut = CreateMutexEx(0,0,0,SYNCHRONIZE|MUTEX_ALL_ACCESS);
	if(!mut)
			throw L5Exception("Can't initialize packet table");

	if(!meta.Write(name))
			return false;

	if(use_memory)
	{
		mt = new PACKET_TABLE_ROW<T>[meta.size];
		if(!mt)
			throw L5Exception("Can't initialize packet table");
		mc = new PACKET_TABLE_ROW<T>[max_collisions];
		if(!mc)
			throw L5Exception("Can't initialize packet table");

	}

	return true;
}

template<class T>
PACKET_TABLE<T>::~PACKET_TABLE(){
	Block();
	CloseHandle(mut);
	int len = sizeof handles / sizeof(HANDLE);
	for(int i = 0; i < len; i++)
		if(handles[i])
			CloseHandle(handles[i]);
	meta.Write(name);

	if(cache)
		delete [] cache;

	if(use_memory){
		delete [] mt;
		delete [] mc;
	}

	if(bufferForeach)
		delete [] bufferForeach;
}

template<class T>
ulong PACKET_TABLE<T>::hash(ulong md5p1, ulong md5p2){
	ulong hash = (md5p1 ^ md5p2) + md5p1;
	ulong res = (hash %  meta.size);
	return res;
};	

template<class T>
int PACKET_TABLE<T>::hash_for_cache(ulong md5p1, ulong md5p2){
	ulong hash = (md5p2 ^ md5p1) + md5p2;
	int res = (hash %  (int) cacheSize);
	return res;
}

template<class T>
bool PACKET_TABLE<T>::Get(ulong md5p1, ulong md5p2, T* out, HANDLE *outfp, ulong* outpos, PACKET_TABLE_ROW<T> *outrow, bool* is_exs){
	Block();
	bool res = false;
	PACKET_TABLE_ROW<T> row;
	memset(&row, 0, sizeof row);
	PACKET_TABLE_ROW_CACHE<PACKET_TABLE_ROW<T>> cacherow;
	memset(&cacherow, 0, sizeof cacherow);

	ulong pos = hash(md5p1, md5p2)  * (ulong) sizeof PACKET_TABLE_ROW<T>;
	HANDLE fp = 0;

	bool is_exists = true;
	bool is_cached = false;
	
	cacherow = cache[hash_for_cache(md5p1, md5p2)];
	if(cacherow.row.md5p1 == md5p1 && cacherow.row.md5p2 == md5p2)
	{
		pos = cacherow.pos;
		fp = cacherow.fp;
		row = cacherow.row;
		is_exists = cacherow.is_exists;
		is_cached = true;
	}
	

	if(!is_cached){
		LARGE_INTEGER l;
		l.QuadPart = pos;
		DWORD read_bytes;
		DWORD written_bytes;
		if(!SetFilePointerEx(handles[1], l, NULL, FILE_BEGIN)){
			Free();
			return false;
		}

		if(!ReadFile(handles[1], &row, sizeof row, &read_bytes, NULL)){
			Free();
			return false;
		}
	
		fp = handles[1];
		_int64 prev_next_pos = -1;
		bool own_num_dec = false;
		while(row.md5p1 != md5p1 || row.md5p2 != md5p2){
				if(row.next_pos == 0)
				{
						is_exists = false;
						if(row.md5p1 == 0 && row.md5p2 == 0){
							row.md5p1 = md5p1;
							row.md5p2 = md5p2;
						}
						else{
							meta.num_collisions++;
						
							if(meta.num_collisions < max_collisions - 1){
								meta.Write(name);

								//expanding...
								row.next_pos = (ulong) ((meta.num_collisions) * sizeof row);
								l.QuadPart = pos;
								if(!SetFilePointerEx(fp, l, NULL, FILE_BEGIN)){
									Free();
									return false;
								}
								if(!WriteFile(fp, &row, sizeof row, &written_bytes, NULL)){
									Free();
									return false;
								}

								pos = row.next_pos;	
								fp = handles[0];
							
								memset(&row, 0, sizeof row);
								row.md5p1 = md5p1;
								row.md5p2 = md5p2;
							}

							//resizing criterium
							if(meta.num_collisions >= max_collisions - 1){
								if(is_in_resizing){
									throw L5Exception("Can't invoke resizing of the table because the procedure is running");
								}
							
								if(!ResizeTable((int) meta.size + size_step)){
									throw L5Exception("Can't resize table");
								}

								if(Get(md5p1, md5p2, out, outfp, outpos, outrow, is_exs)){
									Free();
									return true;
								}
								else{
									Free();
									return false;
								}
							}
						}

						break;
				}

				if(row.next_pos == prev_next_pos)
					throw L5Exception("There is error in elements relations");

				fp = handles[0];
				pos = row.next_pos;
				prev_next_pos = pos;

				l.QuadPart = pos;
				if(!SetFilePointerEx(fp, l, NULL, FILE_BEGIN)){
					Free();
					return false;
				}
			
				if(!ReadFile(fp, &row, sizeof row, &read_bytes, NULL)){
					Free();
					return false;
				}
		}
	}
	
	cacherow.row = row;
	cacherow.pos = pos;
	cacherow.fp = fp;
	cacherow.is_exists = is_exists;
	cache[hash_for_cache(md5p1, md5p2)] = cacherow;
	

	if(outfp != NULL)
		*outfp = fp;
	if(outpos != NULL)
		*outpos = pos;
	if(is_exs != NULL)
		*is_exs = is_exists;
	memcpy(out, &row.val, sizeof T);
	if(outrow != NULL)
		memcpy(outrow, &row, sizeof row);
	
	Free();
	res = true;
	return res;
}

template<class T>
bool PACKET_TABLE<T>::Set(ulong md5p1, ulong md5p2, T* val, bool* is_exs){
	bool res = false;
	//writing
	HANDLE fp = NULL;
	ulong pos;
	PACKET_TABLE_ROW<T> row;
	T fict;
	DWORD written_bytes;
	bool is_exists;
	Block();
	if(Get(md5p1, md5p2, &fict, &fp, &pos, &row, &is_exists)){
		memcpy(&row.val, val, sizeof T);
		LARGE_INTEGER l;
		l.QuadPart = pos;
		if(!SetFilePointerEx(fp, l, NULL, FILE_BEGIN)){
			Free();
			return false;
		}
		if(!WriteFile(fp, &row, sizeof row, &written_bytes, NULL)){
			Free();
			return false;
		}
		PACKET_TABLE_ROW_CACHE<PACKET_TABLE_ROW<T>> cacherow;
		
		memset(&cacherow, 0, sizeof cacherow);
		cacherow.fp = fp;
		cacherow.pos = pos;
		cacherow.is_exists = true;
		cacherow.row = row;
		cache[hash_for_cache(md5p1, md5p2)] = cacherow;

		if(!is_exists)
			meta.rows_written++;
		if(is_exs)
			*is_exs  = is_exists;
		res = true;
	}
	
	Free();
	return res;
} 

template<class T>
bool PACKET_TABLE<T>::ResizeTable(int newSize){
	Block();
	bool res = false;
	string tmpName = name + "_tmp";
	string pNames[3];
	pNames[0] = "packet_table_collision_data_of_" + tmpName + ".dat";
	pNames[1] = "packet_table_meta_data_of_" + tmpName + ".dat";
	pNames[2] = "packet_table_data_of_" + tmpName + ".dat";
	std::stringstream str;
	str << string("Resizing of table ") + name + " in size of " << meta.size << " and collisions of " << meta.num_collisions << " ...";
	opLog(str.str());
	ulong s = time(NULL);
	for(int i = 0; i < 3; i++){
			Poco::Path path(storageDirectory);
			path.append(pNames[i]);
			Poco::File file(path);
			if(file.exists())
				file.remove();
	}

	{
		PACKET_TABLE<T> tmpTable(tmpName, newSize, true);
		const int buff_size = 1010000;
		PACKET_TABLE_ROW<T>* buff = new PACKET_TABLE_ROW<T>[buff_size];

		for(int i = 0; i < 2; i++)
		{
			LARGE_INTEGER l;
			l.QuadPart = 0;
			if(!SetFilePointerEx(handles[i], l, NULL, FILE_BEGIN)){
				Free();
				return false;
			}

			ulong size = (i != 0)?meta.size:max_collisions;

			for(ulong j = 0; j < size;){
				int read_bytes;
				DWORD dw;
				if(!ReadFile(handles[i], buff, buff_size * sizeof(PACKET_TABLE_ROW<T>), &dw, NULL)){
					Free();
					return false;
				}
				read_bytes = dw;
				int read_rows = read_bytes / sizeof(PACKET_TABLE_ROW<T>);
				j+=read_rows;
	
				for(int k = 0; k < read_rows; k++)
						if((buff[k].md5p1 != 0 || buff[k].md5p2 != 0)){
								if(!tmpTable.Set(buff[k].md5p1, buff[k].md5p2, &buff[k].val)){
									Free();
									return false;
								}
						}
			}
			
			CloseHandle(handles[i]);
		}
		delete [] buff;

		memcpy(&meta, &tmpTable.meta, sizeof meta);
	}

	for(int i = 0; i < 2; i++){
		string pName, pName2;
		if(i == 0){
			pName = "packet_table_collision_data_of_" + tmpName + ".dat";
			pName2 = "packet_table_collision_data_of_" + name + ".dat";
		}
		else{
			pName = "packet_table_data_of_" + tmpName + ".dat";
			pName2 = "packet_table_data_of_" + name + ".dat";
		}
			
		//renaming of files
		Poco::Path path(storageDirectory);
		path.append(pName);
		Poco::Path path2(storageDirectory);
		path2.append(pName2);
		Poco::File file2(path2);
		file2.remove();
		Poco::File file(path);
		file.renameTo(path2.toString());
	}
	
	meta.Write(name);
	if(Initial(0, true)){
		res = true;
	}
	ResetForeach();
	str.str("");
	str << "Resizing table of " + name + " has been completed for " << (time(NULL) - s) << "; new size: " << meta.size;
	opLog(str.str());

	Free();
	return res;
};

template<class T>
bool PACKET_TABLE<T>::Delete(ulong md5p1, ulong md5p2){
	T fict_val;
	HANDLE fp;
	ulong pos;
	PACKET_TABLE_ROW<T> row;
	bool is_exists = false;
	DWORD written_bytes;
	Block();
	if(Get(md5p1, md5p2, &fict_val, &fp, &pos, &row, &is_exists) && is_exists){
			LARGE_INTEGER l;
			l.QuadPart = pos;
			if(!SetFilePointerEx(fp, l, NULL, FILE_BEGIN)){
				Free();
				return false;
			}
			memset(&row.val, 0, sizeof(T));

			is_exists = true;

			PACKET_TABLE_ROW_CACHE<PACKET_TABLE_ROW<T>> cacherow;
			memset(&cacherow, 0, sizeof cacherow);
			cacherow.fp = fp;
			cacherow.pos = pos;
			cacherow.is_exists = is_exists;
			cacherow.row = row;
			cache[hash_for_cache(md5p1, md5p2)] = cacherow;

			if(WriteFile(fp, &row, sizeof row, &written_bytes, NULL)){
				Free();
				return true;
			}
	}
	Free();
	return false;
};

template<class T>
bool PACKET_TABLE<T>::Next(ulong& amd5p1, ulong& amd5p2, T* out){
	bool res = true;
	int limitOfBufferForeach = 26666;
	Block();
	if(!bufferForeach){
		bufferForeach = new PACKET_TABLE_ROW<T>[limitOfBufferForeach];
		if(!bufferForeach)
			throw L5Exception("Can't get next element in packet table");
		sizeOfBufferForeach = 0;
		countInBufferForeach = 0;
	}

	ulong md5p1 = 0;
	ulong md5p2 = 0;
	PACKET_TABLE_ROW<T> buff;
	memset(&buff, 0, sizeof buff);

	while(md5p1 == 0 && md5p2 == 0){
		if(countInBufferForeach >= sizeOfBufferForeach){
			LARGE_INTEGER l;
			l.QuadPart = posForeach * sizeof(PACKET_TABLE_ROW<T>);
			if(!SetFilePointerEx(handles[handleForeach], l, NULL, FILE_BEGIN)){
				  throw L5Exception("Can't get next element in packet table");
			}

			int read_bytes;
			DWORD dw;
			if(!ReadFile(handles[handleForeach], bufferForeach, sizeof(PACKET_TABLE_ROW<T>) * limitOfBufferForeach, &dw, NULL)){
				   throw L5Exception("Can't get next element in packet table");
			}

			sizeOfBufferForeach = dw / sizeof(PACKET_TABLE_ROW<T>);
			countInBufferForeach = 0;
		}

		buff = bufferForeach[countInBufferForeach++];

		md5p1 = buff.md5p1;
		md5p2 = buff.md5p2;

		posForeach++;
		if(handleForeach == 0 && (posForeach >= max_collisions))
		{
				posForeach = 0;
				handleForeach = 1;
		}
		else if(handleForeach == 1 && (posForeach >= meta.size)){
			res = false;
			posForeach = handleForeach = 0;
			break;
		}
	}
	
	amd5p1 = md5p1;
	amd5p2 = md5p2;
	Free();

	if(out)
		memcpy(out, &buff.val, sizeof(T));
	if(amd5p1 == 0 && amd5p2 == 0)
		return false;

	return res;
};

template<class T>
bool PACKET_TABLE<T>::Block(){
	if(WaitForSingleObject(mut, INFINITE) == WAIT_FAILED)
		return false;
	else
		return true;
};

template<class T>
bool PACKET_TABLE<T>::Free(){
	return ReleaseMutex(mut);
};

class PACKET_TABLE_DATA{
	public:
		ulong lastSellPos; 
		ulong lastBuyPos;
		ulong posInStorage;
};

PACKET_TABLE<PACKET_TABLE_DATA>* packetTable = 0;
//END FHASH TABLE

//TIME QUEUE
const int BUY_SIGNAL  = 1;
const int SELL_SIGNAL = 2;

class TIME_QUEUE_ROW{
	public:
		unsigned int moment;
		ulong prevPos;
		float price;
};

class TIME_QUEUE_REGISTER_ROW {
	public:
		ulong md5p1;
		ulong md5p2;
		unsigned int moment;
		char signalType;
		float price;
};

class TIME_QUEUE_REGISTER_ROW_POINTER{
	public:
		unsigned int moment;
		ulong pos;
		TIME_QUEUE_REGISTER_ROW* block;
		int blockSize;
		int posOfMaxForBuyReq;
		int posOfMaxForSellReq;
		unsigned int momentForBuyReq;
		unsigned int momentForSellReq;
		unsigned int start_moment;
		float priceForSellReq;
		float priceForBuyReq;
		bool only_load;
};

class TIME_QUEUE{
	private:
		ulong signalsNum;
		ulong registeredMomentsNum;
		HANDLE filehandle;
		HANDLE regFilehandle;
		HANDLE mut;
		std::vector<TIME_QUEUE_REGISTER_ROW_POINTER> rrpointers;
		bool Block();
		bool Free();
		unsigned int prevStartMomentInFinding;
		unsigned int prevLastMomentInFinding;
		int prevBlockIndexForBuyReq;
		int prevBlockIndexForSellReq;
		int prevPosInBlockForBuyReq;
		int prevPosInBlockForSellReq;
		ulong blocksSize;
		bool GetBlockInFinding(int index, TIME_QUEUE_REGISTER_ROW_POINTER& out, bool with_loaded = false);

	public:
		TIME_QUEUE();
		~TIME_QUEUE();
		bool SignalWrite(ulong prevPos, unsigned int moment, float price, ulong& outPos);
		bool ResolveQueue(ulong lastPos, unsigned int** outMoments, float** prices, int& outSize);
		bool Clear();
		bool RegisterMoment(ulong md5p1, ulong md5p2, unsigned int moment, char signalType, float price);
		bool FindPacketsInArea(unsigned int start_time, unsigned int end_time, float start_price, char requiredSignalType, ulong&outmd5p1, ulong&outmd5p2, float& efficency, unsigned int& outmoment);
		ulong GetSignalsNum(){ return signalsNum; }
		ulong GetRegisteredNum() { return registeredMomentsNum; }
		ulong GetSizePointersBuffForFindingPackets() { return rrpointers.size(); }
		void  ClearBuffOfRegisteredMoments();
};

TIME_QUEUE::TIME_QUEUE(){
		prevStartMomentInFinding = prevLastMomentInFinding = 0;
		prevBlockIndexForBuyReq = prevBlockIndexForSellReq = prevPosInBlockForBuyReq = prevPosInBlockForSellReq = 0;
		blocksSize = 0;

		string pName = "time_queue_data.dat";
		Poco::Path path(storageDirectory);
		path.append(pName);
		Poco::File file(path);
		if(!file.exists())
			file.createFile();
		std::wstring wpath;
		Poco::UnicodeConverter::toUTF16(path.toString(), wpath);
		filehandle = CreateFileW(wpath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if(filehandle == INVALID_HANDLE_VALUE)
			throw L5Exception("Can't initialize time queue");
		LARGE_INTEGER p,op;
		p.QuadPart = 0;
		if(!SetFilePointerEx(filehandle, p, &op, FILE_END))
				throw L5Exception("Can't initialize time queue");
		
		if(op.QuadPart == 0){
			signalsNum = 0;

			if(!SetFilePointerEx(filehandle, p, &op, FILE_BEGIN))
				throw L5Exception("Can't initialize time queue");
			TIME_QUEUE_ROW data;
			memset(&data, 0, sizeof data);
			DWORD wrBytes;
			if(!WriteFile(filehandle, &data, sizeof data, &wrBytes, NULL))
				throw L5Exception("Can't initialize time queue");
		}	
		else{
			signalsNum = (op.QuadPart) / sizeof(TIME_QUEUE_ROW) - 1;
			int blockSize = 500000;
			TIME_QUEUE_ROW* rows = new TIME_QUEUE_ROW[blockSize];
			if(!rows)
				throw L5Exception("Can't initialize time queue");
			DWORD dw;
			p.QuadPart = sizeof(TIME_QUEUE_ROW);
			if(!SetFilePointerEx(filehandle, p, &op, FILE_BEGIN))
				throw L5Exception("Can't initialize time queue");
			do{
				if(!ReadFile(filehandle, rows, sizeof(TIME_QUEUE_ROW) * blockSize , &dw, NULL))
					throw L5Exception("Can't initialize time queue");
				int readBytes = dw / sizeof(TIME_QUEUE_ROW);
				for(int k = 0; k < readBytes; k++){
					if(!rows[k].moment){
						signalsNum--;
					}
				}
			}while(dw >= blockSize * sizeof(TIME_QUEUE_ROW));

			delete [] rows;
		}

		mut = CreateMutexEx(0,0,0,SYNCHRONIZE|MUTEX_ALL_ACCESS);
		if(!mut)
			throw L5Exception("Can't initialize time queue");

		pName = "register_moments_data.dat";
		Poco::Path path2(storageDirectory);
		path2.append(pName);
		Poco::File file2(path2);
		if(!file2.exists())
			file2.createFile();
		Poco::UnicodeConverter::toUTF16(path2.toString(), wpath);
		regFilehandle = CreateFileW(wpath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if(regFilehandle == INVALID_HANDLE_VALUE)
			throw L5Exception("Can't initialize time queue");
		p.QuadPart = 0;
		if(!SetFilePointerEx(regFilehandle, p, &op, FILE_END))
				throw L5Exception("Can't initialize time queue");
		if(op.QuadPart != 0){
			p.QuadPart = 0;
			if(!SetFilePointerEx(regFilehandle, p, &op, FILE_BEGIN))
				throw L5Exception("Can't initialize time queue");
			int blockSize = 250000;
			TIME_QUEUE_REGISTER_ROW* rows = new TIME_QUEUE_REGISTER_ROW[blockSize];
			if(!rows)
				throw L5Exception("Can't initialize time queue");
			TIME_QUEUE_REGISTER_ROW_POINTER pi;
			memset(&pi, 0, sizeof pi);
			DWORD dw;
			unsigned int prevMom = 0;
			int count = 0;
			do{
				if(!ReadFile(regFilehandle, rows, sizeof(TIME_QUEUE_REGISTER_ROW) * blockSize , &dw, NULL))
					throw L5Exception("Can't initialize time queue");
				int readBytes = dw / sizeof(TIME_QUEUE_REGISTER_ROW);
				for(int k = 0; k < readBytes; k++){
					if(rows[k].moment - prevMom >= regMomGranularity){
						prevMom = rows[k].moment;
						pi.moment = rows[k].moment;
						pi.pos = count * sizeof(TIME_QUEUE_REGISTER_ROW);
						pi.block = 0;
						rrpointers.push_back(pi);
					}
					count++;
				}
			}while(dw >= blockSize * sizeof(TIME_QUEUE_REGISTER_ROW));
			registeredMomentsNum = count;
			delete [] rows;
		}
		else
			registeredMomentsNum = 0;
};

TIME_QUEUE::~TIME_QUEUE(){
	Block();

	
	ClearBuffOfRegisteredMoments();

	CloseHandle(mut);
	CloseHandle(filehandle);
	CloseHandle(regFilehandle);
};

bool TIME_QUEUE::Block(){
	if(WaitForSingleObject(mut, INFINITE) == WAIT_FAILED)
		return false;
	else
		return true;
};

bool TIME_QUEUE::Free(){
	return ReleaseMutex(mut);
};

bool TIME_QUEUE::SignalWrite(ulong prevPos, unsigned int moment, float price, ulong& outPos){
		TIME_QUEUE_ROW row;
		memset(&row, 0, sizeof row);
		row.prevPos = prevPos;
		row.moment = moment;
		row.price = price;
		
		LARGE_INTEGER p,op;
		p.QuadPart = 0;
		Block();
		if(!SetFilePointerEx(filehandle, p, &op, FILE_END))
		{
				Free();
				return false;
		}
		DWORD wrBytes;
		if(!WriteFile(filehandle, &row, sizeof row, &wrBytes, NULL)){
				Free();
				return false;
		}
		outPos = op.QuadPart;
		Free();
		signalsNum++;
		return true;
};

bool TIME_QUEUE::ResolveQueue(ulong lastPos, unsigned int **outMoments, float** outprices, int& outSize){
	std::vector<unsigned int> buffM;
	std::vector<float> buffP;
	ulong pos = lastPos;
	Block();
	LARGE_INTEGER p;
	TIME_QUEUE_ROW row;
	ulong prev_pos = 0;	

	while(pos){
		p.QuadPart = pos;
		if(!SetFilePointerEx(filehandle, p, NULL, FILE_BEGIN))
		{
				Free();
				return false;
		}
		DWORD dw;
		if(!ReadFile(filehandle, &row, sizeof row, &dw, NULL)){
			Free();
			return false;
		}
		
		buffM.push_back(row.moment);
		buffP.push_back(row.price);
		pos = row.prevPos;
		if(pos && pos == prev_pos)
			return false;
		prev_pos = pos;

		if(!is_in_weekend_processing){
			memset(&row, 0, sizeof row);
			if(!SetFilePointerEx(filehandle, p, NULL, FILE_BEGIN))
			{
					Free();
					return false;
			}
			if(!WriteFile(filehandle, &row, sizeof row, &dw, NULL)){
						Free();
						return false;
			}
		}
	};
	Free();
	
	int len = buffM.size();
	outSize = len;
	if(len > 0){
		unsigned int *outMomentsA = new unsigned int[len];
		float *outpricesA = new float[len];
		if(!outMomentsA || !outpricesA)
			return false;
		for(int i = 0; i < len; i++){
			outMomentsA[i] = buffM[i];
			outpricesA[i] = buffP[i];
		}

		*outMoments = outMomentsA;
		*outprices = outpricesA;
	}
	else{
		*outMoments = 0;
		*outprices = 0;
	}

	signalsNum -= len;

	return true;
};
	
bool TIME_QUEUE::Clear(){
	bool res = true;

	string pName = "time_queue_data_tmp.dat";
	Poco::Path path(storageDirectory);
	path.append(pName);
	Poco::File file(path);
	if(!file.exists())
		file.createFile();
	std::wstring wpath;
	Poco::UnicodeConverter::toUTF16(path.toString(), wpath);
	HANDLE newFilehandle = CreateFileW(wpath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(newFilehandle == INVALID_HANDLE_VALUE){
			throw L5Exception("Can't clear time queue");
	}
	LARGE_INTEGER p,op;
	p.QuadPart = 0;
	if(!SetFilePointerEx(newFilehandle, p, &op, FILE_BEGIN)){
			throw L5Exception("Can't clear time queue");
	}
	if(!SetEndOfFile(newFilehandle)){
			throw L5Exception("Can't clear time queue");
	}
	TIME_QUEUE_ROW data;
	memset(&data, 0, sizeof data);
	DWORD wrBytes;
	if(!WriteFile(newFilehandle, &data, sizeof data, &wrBytes, NULL))
		throw L5Exception("Can't clear time queue");
	Block();

	pName = "time_queue_data.dat";
	Poco::Path path2(storageDirectory);
	path2.append(pName);
	Poco::File file2(path2);

	pName = "time_queue_data_copy.dat";
	Poco::Path path3(storageDirectory);
	path3.append(pName);
	Poco::File file3(path3);
	if(file3.exists())
		file3.remove();
	file2.copyTo(path3.toString());
	
	ulong md5p1, md5p2;
	PACKET_TABLE_DATA val;
	unsigned int* moments;
	float* prices;
	int size;
	ulong count = 1;
	packetTable->ResetForeach();
	while(packetTable->Next(md5p1, md5p2, &val)){
		if(val.lastBuyPos){
			if(!ResolveQueue(val.lastBuyPos, &moments, &prices, size))
			{
				throw L5Exception("Can't clear time queue");
			}

			ulong prevPos = 0;
			for(int i = size - 1; i >= 0; i--){
				memset(&data, 0, sizeof data);
				data.moment = moments[i];
				data.price = prices[i];
				data.prevPos = prevPos;
				prevPos = count * sizeof(TIME_QUEUE_ROW);
				count++;
				if(!WriteFile(newFilehandle, &data, sizeof data, &wrBytes, NULL))
					throw L5Exception("Can't clear time queue");
			}
			val.lastBuyPos = prevPos;
			if(size){
				delete [] moments;
				delete [] prices;
			}
		}

		if(val.lastSellPos){
			if(!ResolveQueue(val.lastSellPos, &moments, &prices, size))
			{
				throw L5Exception("Can't clear time queue");
			}
			ulong prevPos = 0;
			for(int i = size - 1; i >= 0; i--){
				memset(&data, 0, sizeof data);
				data.moment = moments[i];
				data.prevPos = prevPos;
				prevPos = count * sizeof(TIME_QUEUE_ROW);
				count++;
				if(!WriteFile(newFilehandle, &data, sizeof data, &wrBytes, NULL))
					throw L5Exception("Can't clear time queue");
			}
			val.lastSellPos = prevPos;
			if(size){
				delete [] moments;
				delete [] prices;
			}
		}

		packetTable->Set(md5p1, md5p2, &val);
	}
	

	CloseHandle(filehandle);
	CloseHandle(newFilehandle);
	
	file2.remove();
	file.renameTo(path2.toString());
	file3.remove();

	Poco::UnicodeConverter::toUTF16(path2.toString(), wpath);
	filehandle = CreateFileW(wpath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(filehandle == INVALID_HANDLE_VALUE)
			throw L5Exception("Can't clear time queue");

	//Clear register moments
	//TO DO

	Free();
	return res;
};	

bool TIME_QUEUE::RegisterMoment(ulong md5p1, ulong md5p2, unsigned int moment, char signalType, float price){
	Block();
	LARGE_INTEGER p, op;
	DWORD dw, wrBytes;
	TIME_QUEUE_REGISTER_ROW row;
	memset(&row, 0, sizeof row);
	row.md5p1 = md5p1;
	row.md5p2 = md5p2;
	row.moment = moment;
	row.signalType = signalType;
	row.price = price;
	
	p.QuadPart = 0;
	if(!SetFilePointerEx(regFilehandle, p, &op, FILE_END)){
			Free();
			return false;	
	}

	if(!WriteFile(regFilehandle, &row, sizeof row, &wrBytes, NULL)){
		  Free();
		  return false;
	}
	
	bool pwritingNeeded = false;
	if(rrpointers.size() == 0)
		pwritingNeeded = true;
	else if(moment - rrpointers[rrpointers.size()-1].moment >= regMomGranularity)
		pwritingNeeded = true;
		
	if(pwritingNeeded){
		TIME_QUEUE_REGISTER_ROW_POINTER p;
		memset(&p, 0, sizeof p);
		p.pos = op.QuadPart;
		p.moment = moment;
		rrpointers.push_back(p);
	}

	Free();

	registeredMomentsNum++;

	return true;
}

bool TIME_QUEUE::GetBlockInFinding(int index, TIME_QUEUE_REGISTER_ROW_POINTER& out, bool with_loaded){
	LARGE_INTEGER st,en,p;
	DWORD dw, wrBytes;
	int len = rrpointers.size();
	if(!with_loaded && rrpointers[index].only_load)
	{
		out = rrpointers[index];
		return true;
	}
	
	if(!rrpointers[index].block || index == len - 1){
		Block();

		st.QuadPart = rrpointers[index].pos;
		if(index != len - 1)
			en.QuadPart = rrpointers[index + 1].pos;
		else{
			p.QuadPart = 0;
			if(!SetFilePointerEx(regFilehandle, p, &en, FILE_END)){
				Free();
				return false;	
			}
		}

		out = rrpointers[index];
		int blockSize = (en.QuadPart - st.QuadPart) /  sizeof(TIME_QUEUE_REGISTER_ROW);
		
		if(blockSize == 0)
		{
			Free();
			return true;
		}
		
		TIME_QUEUE_REGISTER_ROW* block = new TIME_QUEUE_REGISTER_ROW[blockSize];
		if(!block){
			opLog("Can't allocate memory in finding of packets in area");
			Free();
			return false;
		}

		if(!SetFilePointerEx(regFilehandle, st, &p, FILE_BEGIN)){
				Free();
				return false;	
		}

		if(!ReadFile(regFilehandle, block, blockSize * sizeof(TIME_QUEUE_REGISTER_ROW), &dw, NULL)){
				Free();
				return false;
		}

		blocksSize += dw;

		blockSize = dw / sizeof(TIME_QUEUE_REGISTER_ROW);
		if(blockSize == 0)
		{
			Free();
			return true;
		}
		
		if(rrpointers[index].block){
			blocksSize -= rrpointers[index].blockSize * sizeof(TIME_QUEUE_REGISTER_ROW);
			delete [] rrpointers[index].block;
		}
		rrpointers[index].block = block;
		rrpointers[index].blockSize = blockSize;

		if(rrpointers[index].only_load)
		{
			out = rrpointers[index];
			Free();
			return true;
		}

		//finding of maximal price
		float maxInBuyInputSignal = 0;
		float maxInSellInputSignal = MAXDWORD;
		int posForSell = -1;
		int posForBuy = -1;
		for(int k = 0; k < blockSize; k++){
				if(block[k].signalType == SELL_SIGNAL && block[k].price > maxInBuyInputSignal){
					maxInBuyInputSignal=block[k].price;
					posForSell = k;
				}

				if(block[k].signalType == BUY_SIGNAL && block[k].price < maxInSellInputSignal){
					maxInSellInputSignal=block[k].price;
					posForBuy = k;
				}
		}
		rrpointers[index].posOfMaxForBuyReq = posForBuy;
		rrpointers[index].posOfMaxForSellReq = posForSell;
		if(posForBuy != -1){
			rrpointers[index].momentForBuyReq = block[posForBuy].moment;
			rrpointers[index].priceForBuyReq = block[posForBuy].price;
		}
		else{
			rrpointers[index].priceForBuyReq = MAXDWORD;
		}

		if(posForSell != -1){
			rrpointers[index].momentForSellReq = block[posForSell].moment;
			rrpointers[index].priceForSellReq = block[posForSell].price;
		}
		else{
			rrpointers[index].priceForSellReq = 0;
		}

		rrpointers[index].start_moment = block[0].moment;
		if(index != len - 1)
			rrpointers[index].only_load = true;

		Free(); 
	}
	
	out = rrpointers[index];
	if(blocksSize > maximalBufferSizeForFindingOfSuitablePackets){
		int count = 0;
		for(int i = 0; i < len; i++){
			if(rrpointers[i].block && i != index)
			{
				blocksSize -= rrpointers[i].blockSize * sizeof(TIME_QUEUE_REGISTER_ROW);
				rrpointers[i].blockSize = 0;
				delete [] rrpointers[i].block;
				rrpointers[i].block = 0;
				if(count++ > 7)
					break;
			}
		}
	}

	return true;
}


bool TIME_QUEUE::FindPacketsInArea(unsigned int start_time, unsigned int end_time, float start_price, char requiredSignalType, ulong&outmd5p1, ulong&outmd5p2, float& efficency, unsigned int& outmoment){
	bool requiredReading = true;
	if(start_time == prevStartMomentInFinding && end_time == prevLastMomentInFinding){
		requiredReading = false;
	}

	int len = rrpointers.size();
	if(!len)
	{
		outmoment = 0;
		return true;
	}

	if(requiredReading){
		int stP = 0, lastP = 0;
		bool f1 = false, f2 = false;
		
		for(int i = 0; i < len; i++){
			if(!f1 && i != len-1 && rrpointers[i].moment <= start_time && rrpointers[i + 1].moment > start_time){
				stP = i;
				f1 = true;
			}
			else if(!f1 && i == len - 1){
				stP = i;
				f1 = true;
			}

			if(!f2 && i != len-1 && rrpointers[i].moment <= end_time && rrpointers[i + 1].moment > end_time){
				lastP = i;
				f2 = true;
			}
			else if(!f2 && i == len - 1){
				lastP = i;
				f2 = true;
			}
			if(f1 && f2)
				break;
		}
		lastP++;

		//finding of maximal price
		float maxInBuyInputSignal = 0;
		float maxInSellInputSignal = MAXDWORD;
		int blockPosForSell = -1;
		int blockPosForBuy = -1;
		int posInBlockForSell = -1;
		int posInBlockForBuy = -1;
		TIME_QUEUE_REGISTER_ROW_POINTER data;
		TIME_QUEUE_REGISTER_ROW_POINTER frontData;

		for(int i = stP; i < lastP; i++){
			if(!GetBlockInFinding(i, data)){
				return false;
			}

			float buyPrice = data.priceForSellReq;
			float sellPrice = data.priceForBuyReq;
			
			if(buyPrice > maxInBuyInputSignal){
				if(data.momentForSellReq < start_time)
					if(i != lastP - 1 && !GetBlockInFinding(i + 1, frontData))
						return false;

				if(((data.momentForSellReq < start_time && (i == lastP - 1 || frontData.momentForSellReq > start_time)) ||
					(data.momentForSellReq > end_time && (data.start_moment <= end_time)))
						){ 
						//loop into the block
						if(!GetBlockInFinding(i, data, true)){
							return false;
						}

						TIME_QUEUE_REGISTER_ROW* block = data.block;
						int blockSize = data.blockSize;
						float maxInBuyInputSignal2 = 0;
						unsigned int momentForSellReq2 = 0;
						int posInBlockForSell2 = -1;
						for(int k = 0; k < blockSize; k++){
							if(block[k].signalType == SELL_SIGNAL && block[k].moment >= start_time && block[k].moment <= end_time){
								if(block[k].price > maxInBuyInputSignal2){
									maxInBuyInputSignal2=block[k].price;
									posInBlockForSell2 = k;
									momentForSellReq2 = block[k].moment;
								}
							}
						}

						if(maxInBuyInputSignal2 > maxInBuyInputSignal){
							maxInBuyInputSignal = maxInBuyInputSignal2;
							blockPosForSell = i;
							posInBlockForSell = posInBlockForSell2;
						}
				}
				else if(data.momentForSellReq > start_time && data.momentForSellReq <= end_time){
					maxInBuyInputSignal=buyPrice;
					blockPosForSell = i;
					posInBlockForSell = data.posOfMaxForSellReq;
				}
			}
			
			if(sellPrice < maxInSellInputSignal){
				if(data.momentForBuyReq < start_time)
					if(i != lastP - 1 && !GetBlockInFinding(i + 1, frontData))
						return false;

				if(((data.momentForBuyReq < start_time && (i == lastP - 1 || frontData.momentForBuyReq > start_time)) ||
					(data.momentForBuyReq > end_time && (data.start_moment <= end_time)))
						){ 
						//loop into the block
						if(!GetBlockInFinding(i, data, true)){
							return false;
						}

						TIME_QUEUE_REGISTER_ROW* block = data.block;
						int blockSize = data.blockSize;
						float maxInSellInputSignal2 = 0;
						unsigned int momentForBuyReq2 = 0;
						int posInBlockForBuy2 = -1;
						for(int k = 0; k < blockSize; k++){
							if(block[k].signalType == BUY_SIGNAL && block[k].moment >= start_time && block[k].moment <= end_time){
								if(block[k].price < maxInSellInputSignal2){
									maxInSellInputSignal2=block[k].price;
									posInBlockForBuy2 = k;
									momentForBuyReq2 = block[k].moment;
								}
							}
						}

						if(maxInSellInputSignal2 > maxInSellInputSignal){
							maxInSellInputSignal = maxInSellInputSignal2;
							blockPosForBuy = i;
							posInBlockForBuy = posInBlockForBuy2;
						}
				}
				else if(data.momentForBuyReq > start_time && data.momentForBuyReq <= end_time){
					maxInSellInputSignal=sellPrice;
					blockPosForBuy = i;
					posInBlockForBuy = data.posOfMaxForBuyReq;
				}
			}
		}

		prevBlockIndexForSellReq = blockPosForSell;
		prevBlockIndexForBuyReq = blockPosForBuy;
		prevPosInBlockForSellReq = posInBlockForSell;
		prevPosInBlockForBuyReq = posInBlockForBuy;
	}
	
	prevStartMomentInFinding = start_time; 
	prevLastMomentInFinding = end_time;
	int blockPos = requiredSignalType == SELL_SIGNAL?prevBlockIndexForSellReq:prevBlockIndexForBuyReq;
	int pos = requiredSignalType == SELL_SIGNAL?prevPosInBlockForSellReq:prevPosInBlockForBuyReq;

	if(pos == -1){
		outmoment = 0;
		return true;
	}

	TIME_QUEUE_REGISTER_ROW_POINTER data;
	if(!GetBlockInFinding(blockPos, data, true)){
		return false;
	}
	if(data.block[pos].moment > start_time && data.block[pos].moment <= end_time)
	{
		outmd5p1 = data.block[pos].md5p1;
		outmd5p2 = data.block[pos].md5p2;
		outmoment = data.block[pos].moment;
		efficency = data.block[pos].signalType == BUY_SIGNAL?start_price - data.block[pos].price:data.block[pos].price - start_price;
	}
	else
		outmoment = 0;

	return true;
}

void TIME_QUEUE::ClearBuffOfRegisteredMoments(){
	for(int i = 0; i < rrpointers.size(); i++){
		if(rrpointers[i].block)
		{
			blocksSize -= rrpointers[i].blockSize * sizeof(TIME_QUEUE_REGISTER_ROW);
			rrpointers[i].blockSize = 0;
			delete [] rrpointers[i].block;
			rrpointers[i].block = 0;
		}
	}
};

TIME_QUEUE* timeQueue = 0;

//END TIME QUEUE
//PRICE QUEUE
class PRICE_QUEUE_ROW {
	public:
		float stopLoss;  
		float startPrice;
		unsigned int moment; 
		ulong md5p1;
		ulong md5p2;
};

class PRICE_QUEUE {
	private:
		HANDLE handles[2];
		ulong currentPosInSell;
		ulong currentPosInBuy;
		bool findSuitablePos(float currentPrice, char signalType, ulong& outPosIn, bool begin_from_start = false);
		ulong signalsInBuy;
		ulong signalsInSell;

	public:
		PRICE_QUEUE(float currentPriceAsk, float currentPriceBid);
		~PRICE_QUEUE();
		bool SignalsWrite(float stopLoss, float currentPrice, ulong* moments, ulong* md5p1, ulong* md5p2, char signalType, int size);
		bool ResolveQueues(float currentPrice, PRICE_QUEUE_ROW** out, char** signalTypes, int& outsize);
		ulong GetSignalsInBuy() { return signalsInBuy; }
		ulong GetSignalsInSell() { return signalsInSell; }
};

PRICE_QUEUE::PRICE_QUEUE(float currentPriceAsk, float currentPriceBid){
	currentPosInSell = currentPosInBuy = sizeof(PRICE_QUEUE_ROW);

	string pName = "price_queue_buy_data.dat";
	Poco::Path path(storageDirectory);
	path.append(pName);
	Poco::File file(path);
	if(!file.exists())
		file.createFile();
	std::wstring wpath;
	Poco::UnicodeConverter::toUTF16(path.toString(), wpath);
	handles[0] = CreateFileW(wpath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(handles[0] == INVALID_HANDLE_VALUE)
		throw L5Exception("Can't initialize price queue");
	LARGE_INTEGER p,op;
	p.QuadPart = 0;
	if(!SetFilePointerEx(handles[0], p, &op, FILE_END))
			throw L5Exception("Can't initialize price queue");
	if(op.QuadPart == 0){
		signalsInBuy = 0;
			if(!SetFilePointerEx(handles[0], p, &op, FILE_BEGIN))
				throw L5Exception("Can't initialize price queue");
			PRICE_QUEUE_ROW data;
			memset(&data, 0, sizeof data);
			DWORD wrBytes;
			if(!WriteFile(handles[0], &data, sizeof data, &wrBytes, NULL))
				throw L5Exception("Can't initialize price queue");
	}	
	else
		signalsInBuy = op.QuadPart / sizeof(PRICE_QUEUE_ROW) - 1;

	pName = "price_queue_sell_data.dat";
	Poco::Path path2(storageDirectory);
	path2.append(pName);
	Poco::File file2(path2);
	if(!file2.exists())
		file2.createFile();
	Poco::UnicodeConverter::toUTF16(path2.toString(), wpath);
	handles[1] = CreateFileW(wpath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(handles[1] == INVALID_HANDLE_VALUE)
		throw L5Exception("Can't initialize price queue");
	p.QuadPart = 0;
	if(!SetFilePointerEx(handles[1], p, &op, FILE_END))
			throw L5Exception("Can't initialize price queue");
	if(op.QuadPart == 0){
		signalsInSell = 0;
		if(!SetFilePointerEx(handles[1], p, &op, FILE_BEGIN))
			throw L5Exception("Can't initialize price queue");
		PRICE_QUEUE_ROW data;
		memset(&data, 0, sizeof data);
		DWORD wrBytes;
		if(!WriteFile(handles[1], &data, sizeof data, &wrBytes, NULL))
			throw L5Exception("Can't initialize price queue");
	}	
	else
		signalsInSell = op.QuadPart / sizeof(PRICE_QUEUE_ROW) - 1;

	if(!findSuitablePos(currentPriceBid, BUY_SIGNAL, currentPosInBuy) || !findSuitablePos(currentPriceAsk, SELL_SIGNAL, currentPosInSell))
		throw L5Exception("Can't initialize price queue");
}

PRICE_QUEUE::~PRICE_QUEUE(){
	CloseHandle(handles[0]);
	CloseHandle(handles[1]);
}

bool PRICE_QUEUE::findSuitablePos(float currentPrice, char signalType, ulong& outpos, bool begin_from_start){
	PRICE_QUEUE_ROW row;
	memset(&row, 0, sizeof row);
	
	if(signalType == BUY_SIGNAL){
		LARGE_INTEGER p, op;
		if(begin_from_start){
			p.QuadPart = 0;
			if(!SetFilePointerEx(handles[0], p, &op, FILE_END))
				return false;
		}
		p.QuadPart = !begin_from_start?currentPosInBuy:op.QuadPart;
		outpos = !begin_from_start?currentPosInBuy:op.QuadPart;

		if(!SetFilePointerEx(handles[0], p, &op, FILE_BEGIN))
			return false;
		DWORD dw;
		if(!ReadFile(handles[0], &row, sizeof row, &dw, NULL)){
			return false;
		}
		
		if(dw != 0 && row.stopLoss <= currentPrice){
			do{
				outpos+= sizeof(PRICE_QUEUE_ROW);
				if(!ReadFile(handles[0], &row, sizeof row, &dw, NULL)){
					return false;
				}
			}while(dw != 0 && row.stopLoss <= currentPrice);
		}
		else{
			while(outpos > sizeof(PRICE_QUEUE_ROW) && (row.stopLoss > currentPrice || dw == 0)){
				outpos -= sizeof(PRICE_QUEUE_ROW);
				p.QuadPart = outpos;
				if(!SetFilePointerEx(handles[0], p, &op, FILE_BEGIN))
					return false;
				if(!ReadFile(handles[0], &row, sizeof row, &dw, NULL)){
					return false;
				}
				if(row.stopLoss <= currentPrice)
					outpos += sizeof(PRICE_QUEUE_ROW);
			};
		}
	}
	else{
		LARGE_INTEGER p, op;
		if(begin_from_start){
			p.QuadPart = 0;
			if(!SetFilePointerEx(handles[1], p, &op, FILE_END))
				return false;
		}
		p.QuadPart = !begin_from_start?currentPosInSell:op.QuadPart;
		outpos = !begin_from_start?currentPosInSell:op.QuadPart;

		if(!SetFilePointerEx(handles[1], p, &op, FILE_BEGIN)){
			return false;
		}

		DWORD dw;
		if(!ReadFile(handles[1], &row, sizeof row, &dw, NULL)){
			return false;
		}

		if(dw != 0 && row.stopLoss >= currentPrice){
			do{
				outpos+= sizeof(PRICE_QUEUE_ROW);
				if(!ReadFile(handles[1], &row, sizeof row, &dw, NULL)){
					return false;
				}
			}while(dw != 0 && row.stopLoss >= currentPrice);
		}
		else{
			
			while(outpos > sizeof(PRICE_QUEUE_ROW) && (row.stopLoss < currentPrice || dw == 0)){
				outpos -= sizeof(PRICE_QUEUE_ROW);
				p.QuadPart = outpos;
				if(!SetFilePointerEx(handles[1], p, &op, FILE_BEGIN)){
					return false;
				}
				if(!ReadFile(handles[1], &row, sizeof row, &dw, NULL)){
					return false;
				}
				if(row.stopLoss >= currentPrice)
					outpos += sizeof(PRICE_QUEUE_ROW);
			};
		}
	}
	
	return true;
}

bool PRICE_QUEUE::SignalsWrite(float stopLoss, float currentPrice, ulong* moments, ulong* md5p1, ulong* md5p2, char signalType, int size){
		HANDLE handle = (signalType == BUY_SIGNAL?handles[0]:handles[1]);
		if(!size)
			return true;
		int addSize = size * sizeof(PRICE_QUEUE_ROW);

		ulong startPos;
		if(!findSuitablePos(stopLoss, signalType, startPos)){
			return false;
		}

		LARGE_INTEGER p, op;
		DWORD dw, wrBytes;
		p.QuadPart = 0;
		if(!SetFilePointerEx(handle, p, &op, FILE_END)){
			return false;
		}

		ulong fileSize = op.QuadPart;
		if(startPos < fileSize){  //expanding of file
			ulong blockSize = fileSize - startPos;
			p.QuadPart = fileSize + addSize;
			if(!SetFilePointerEx(handle, p, &op, FILE_BEGIN)){
				return false;
			}
			if(!SetEndOfFile(handle)){
				return false;
			}
			
			int step = 10000000;
			char* buff = new char[step];
			if(!buff)
				return false;
			ulong copiedSize = 0;
			while(copiedSize < blockSize){
				p.QuadPart = startPos + copiedSize;
				if(!SetFilePointerEx(handle, p, &op, FILE_BEGIN)){
					return false;
				}

				int sizeForReading = blockSize - copiedSize > step?step:blockSize - copiedSize;
				if(!ReadFile(handle, buff, sizeForReading, &dw, NULL)){
					return false;
				}
				
				p.QuadPart = (fileSize + addSize - blockSize) + copiedSize;
				if(!SetFilePointerEx(handle, p, &op, FILE_BEGIN)){
					return false;
				}

				if(!WriteFile(handle, buff, dw, &wrBytes, NULL)){
					return false;
				}

				copiedSize+=dw;
			}
			delete [] buff;
		}

		PRICE_QUEUE_ROW* buff = new PRICE_QUEUE_ROW[size];
		if(!buff)
			return false;
		memset(buff, 0, addSize);
		for(int i = 0; i < size; i++){
			buff[i].stopLoss = stopLoss;
			buff[i].startPrice = currentPrice;
			buff[i].moment = moments[i];
			buff[i].md5p1 = md5p1[i];
			buff[i].md5p2 = md5p2[i];
		}
		
		p.QuadPart = startPos;
		
		if(!SetFilePointerEx(handle, p, &op, FILE_BEGIN)){
			return false;
		}
		
		if(!WriteFile(handle, buff, addSize, &wrBytes, NULL)){
			return false;
		}

		if(signalType == BUY_SIGNAL){
			currentPosInBuy = startPos + addSize;
			signalsInBuy += size;
		}
		else{
			currentPosInSell = startPos + addSize;
			signalsInSell += size;
		}

		delete [] buff;

	return true;
}

bool PRICE_QUEUE::ResolveQueues(float currentPrice, PRICE_QUEUE_ROW ** out, char** signalTypes, int& outsize){
	ulong startPos;
	LARGE_INTEGER p, op;
	DWORD dw, wrBytes;
	int buySize = 0, sellSize = 0;
	ulong mcurrentPosInBuy = 0, mcurrentPosInSell = 0;
	
	//buy resolving
	{
		if(!findSuitablePos(currentPrice - 0.0000001, BUY_SIGNAL, startPos, true))
			return false;
		p.QuadPart = 0;
		if(!SetFilePointerEx(handles[0], p, &op, FILE_END))
			return false;
		ulong fileSize = op.QuadPart;
		if(startPos < fileSize){  
			buySize = fileSize - startPos;
		}
		mcurrentPosInBuy = startPos;
	}

	//sell resolving
	{
		if(!findSuitablePos(currentPrice + 0.0000001, SELL_SIGNAL, startPos, true))
			return false;
		p.QuadPart = 0;
		if(!SetFilePointerEx(handles[1], p, &op, FILE_END))
			return false;
		ulong fileSize = op.QuadPart;
		if(startPos < fileSize){  
			sellSize = fileSize - startPos;
		}
		mcurrentPosInSell = startPos;
	}

	if(buySize + sellSize){
		outsize = (buySize + sellSize) / sizeof(PRICE_QUEUE_ROW);
		*out = new PRICE_QUEUE_ROW[outsize];
		*signalTypes = new char[outsize];
		if(!*out || !*signalTypes)
			return false;
		
		if(buySize){
			p.QuadPart = mcurrentPosInBuy;
			if(!SetFilePointerEx(handles[0], p, &op, FILE_BEGIN))
						return false;

			if(!ReadFile(handles[0], *out, buySize, &dw, NULL))
					   return false;

			if(!SetFilePointerEx(handles[0], p, &op, FILE_BEGIN))
						return false;

			if(!SetEndOfFile(handles[0]))
						return false;

			memset(*signalTypes, BUY_SIGNAL, buySize / sizeof(PRICE_QUEUE_ROW));
			signalsInBuy -= (buySize / sizeof(PRICE_QUEUE_ROW));
		}
		
		if(sellSize){
			p.QuadPart = mcurrentPosInSell;
			if(!SetFilePointerEx(handles[1], p, &op, FILE_BEGIN))
						return false;
			
			if(!ReadFile(handles[1], (void*) (((int) *out) + buySize), sellSize, &dw, NULL))
					   return false;

			if(!SetFilePointerEx(handles[1], p, &op, FILE_BEGIN))
						return false;

			if(!SetEndOfFile(handles[1]))
						return false;

			memset((void*) (((int) *signalTypes) + buySize / sizeof(PRICE_QUEUE_ROW)), SELL_SIGNAL, sellSize / sizeof(PRICE_QUEUE_ROW));
			signalsInSell -= (sellSize / sizeof(PRICE_QUEUE_ROW));
		}	
	}
	else{
		outsize = 0;
	}
	
	return true;
}

PRICE_QUEUE* priceQueue = 0;

//END PRICE QUEUE

//MOMENTS FOR RESOLVING

class MOMENTS_FOR_RES_ROW{
	public:
		unsigned int start_moment;
		unsigned int end_moment;
		ulong md5p1;
		ulong md5p2;
		char signalType;
		float start_price;
		float end_price;
};

class MOMENTS_FOR_RES{
	private:
		HANDLE handle;
		HANDLE mut;
		std::vector<MOMENTS_FOR_RES_ROW> buffer;
		bool Block();
		bool Free();
		ulong signalsNum;

	public:
		MOMENTS_FOR_RES();
		~MOMENTS_FOR_RES();
		bool Write(ulong md5p1, ulong md5p2, ulong start_moment, char signalType, float sprice, float eprice, ulong last_moment = 0);
		bool Get(MOMENTS_FOR_RES_ROW** out, int& outsize, int inlimit = 10000);
		ulong GetSignalsNum(){ return signalsNum; }
		ulong GetSignalsInBuffer() { return buffer.size(); }
		bool FlushBuff(bool force = false);
};

MOMENTS_FOR_RES::MOMENTS_FOR_RES(){
	string pName = "moments_for_resolving_data.dat";
	Poco::Path path(storageDirectory);
	path.append(pName);
	Poco::File file(path);
	if(!file.exists())
		file.createFile();
	std::wstring wpath;
	Poco::UnicodeConverter::toUTF16(path.toString(), wpath);

	handle = CreateFileW(wpath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(handle == INVALID_HANDLE_VALUE)
		throw L5Exception("Can't initialize moments for resolving writer");
	LARGE_INTEGER p, op;
	p.QuadPart = 0;

	if(!SetFilePointerEx(handle, p, &op, FILE_END)){
		throw L5Exception("Can't initialize moments for resolving writer");			
	}
	signalsNum = op.QuadPart / sizeof(MOMENTS_FOR_RES_ROW);

	mut = CreateMutexEx(0,0,0,SYNCHRONIZE|MUTEX_ALL_ACCESS);
	if(!mut)
		throw L5Exception("Can't initialize moments for resolving writer");
}

bool MOMENTS_FOR_RES::Block(){
	if(WaitForSingleObject(mut, INFINITE) == WAIT_FAILED){
		return false;
	}
	else
		return true;
};

bool MOMENTS_FOR_RES::Free(){
	return ReleaseMutex(mut);
};

bool MOMENTS_FOR_RES::FlushBuff(bool force){
	if((buffer.size() >= 5000 || force) && buffer.size() != 0){
		Block();
		LARGE_INTEGER p, op;
		DWORD dw, wrBytes;
		p.QuadPart = 0;
		if(!SetFilePointerEx(handle, p, &op, FILE_END)){
				Free();
				return false;	
		}
		if(!WriteFile(handle, &buffer[0], buffer.size() * sizeof(MOMENTS_FOR_RES_ROW), &wrBytes, NULL)){
				Free();
			    return false;
		}
		signalsNum += buffer.size();
		buffer.clear();
		Free();
	}

	return true;
}

bool MOMENTS_FOR_RES::Write(ulong md5p1, ulong md5p2, ulong start_moment, char signalType, float sprice, float eprice, ulong last_moment){
	MOMENTS_FOR_RES_ROW row;
	Poco::DateTime now;
	ulong timestamp = !last_moment?mql4_get_timestamp():last_moment;
	memset(&row, 0, sizeof row);
	row.md5p1 = md5p1;
	row.md5p2 = md5p2;
	row.start_moment = start_moment;
	row.signalType = signalType;
	row.end_moment = timestamp;
	row.start_price = sprice;
	row.end_price = eprice;
	buffer.push_back(row);

	return FlushBuff();
}

bool MOMENTS_FOR_RES::Get(MOMENTS_FOR_RES_ROW ** out, int& outsize, int inlimit){
	Block();
	const int limit = sizeof(MOMENTS_FOR_RES_ROW) * inlimit;  
	LARGE_INTEGER p, op;
	DWORD dw, wrBytes;
	p.QuadPart = 0;
	if(!SetFilePointerEx(handle, p, &op, FILE_END)){
				Free();
				return false;	
	}

	ulong filesize = op.QuadPart;
	bool by_part = false;
	if(filesize > limit){
		filesize = limit;
		by_part = true;
	}
	else if(!is_in_weekend_processing)
	{
		outsize = 0;
		Free();
		return true;
	}
	
	outsize = filesize / sizeof(MOMENTS_FOR_RES_ROW);
	if(outsize){
		*out = new MOMENTS_FOR_RES_ROW[outsize];
		if(!*out)
		{
			Free();
			return false;
		}

		p.QuadPart = 0;
		if(!SetFilePointerEx(handle, p, &op, FILE_BEGIN)){
				Free();
				return false;	
		}

		if(!ReadFile(handle, *out, outsize * sizeof(MOMENTS_FOR_RES_ROW), &dw, NULL)){
					Free();
					return false;
		}

		if(!by_part){
			p.QuadPart = 0;
			if(!SetFilePointerEx(handle, p, &op, FILE_BEGIN)){
					Free();
					return false;	
			}

			if(!SetEndOfFile(handle)){
					Free();
					return false;	
			}
		}
		else{
			p.QuadPart = filesize;
			if(!SetFilePointerEx(handle, p, &op, FILE_BEGIN)){
					Free();
					return false;	
			}
			int blockSize = 20000000;
			char* buff = new char[blockSize];
			if(!buff){
				Free();
				return false;
			}
		
			int readBytes = 0;
			do{
				if(!ReadFile(handle, buff, blockSize, &dw, NULL)){
					Free();
					return false;
				}

				p.QuadPart = readBytes;
				if(!SetFilePointerEx(handle, p, &op, FILE_BEGIN)){
					Free();
					return false;	
				}
				readBytes += dw;

				if(!WriteFile(handle, buff, dw, &wrBytes, NULL)){
					Free();
					return false;
				}

				p.QuadPart = filesize +  readBytes;
				if(!SetFilePointerEx(handle, p, &op, FILE_BEGIN)){
					Free();
					return false;	
				}

			}while(dw >= blockSize);

			delete [] buff;

			p.QuadPart = readBytes;
			if(!SetFilePointerEx(handle, p, &op, FILE_BEGIN)){
					Free();
					return false;	
			}

			if(!SetEndOfFile(handle)){
					Free();
					return false;	
			}
			
		}
	}

	signalsNum -= outsize;

	Free();
	return true;
}

MOMENTS_FOR_RES::~MOMENTS_FOR_RES(){
	FlushBuff(true);
	Block();
	CloseHandle(handle);
	CloseHandle(mut);
}

MOMENTS_FOR_RES* momsForRes = 0;

//END MOMENTS FOR RESOLVING

//PACKETS STORAGE

class PACKETS_STORAGE_SIGN{
	public:
		unsigned short length;
		ulong md5val;
};

class PACKETS_STORAGE{
	private:
		HANDLE handle;
		HANDLE mut;
		bool Block();
		bool Free();
		ulong sizeOfStorage;

	public:
		PACKETS_STORAGE(int historyNumber = 0);
		~PACKETS_STORAGE();
		bool Write(string& data, ulong& outpos);
		bool Get(ulong pos, string& data);
		ulong GetSizeOfStorage(){ return sizeOfStorage; }
};

PACKETS_STORAGE::PACKETS_STORAGE(int historyNumber){
	char cbuff[10];
	string pName = !historyNumber?"packets_storage.dat":"history_packets_storage" + string(itoa(historyNumber, cbuff, 10)) + ".dat";
	Poco::Path path(storageDirectory);
	path.append(pName);
	Poco::File file(path);
	if(!file.exists())
		file.createFile();
	std::wstring wpath;
	Poco::UnicodeConverter::toUTF16(path.toString(), wpath);
	handle = CreateFileW(wpath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(handle == INVALID_HANDLE_VALUE)
		throw L5Exception("Can't initialize packets storage");
	LARGE_INTEGER p, op;
	p.QuadPart = 0;

	if(!SetFilePointerEx(handle, p, &op, FILE_END)){
		throw L5Exception("Can't initialize moments for resolving writer");			
	}
	sizeOfStorage = op.QuadPart;

	if(!sizeOfStorage){
		DWORD wrBytes;
		char buff;
		if(!WriteFile(handle, &buff, sizeof buff, &wrBytes, NULL)){
				throw L5Exception("Can't initialize moments for resolving writer");	
		}
	}

	mut = CreateMutexEx(0,0,0,SYNCHRONIZE|MUTEX_ALL_ACCESS);
	if(!mut)
		throw L5Exception("Can't initialize packets storage");
}

bool PACKETS_STORAGE::Block(){
	if(WaitForSingleObject(mut, INFINITE) == WAIT_FAILED)
		return false;
	else
		return true;
};

bool PACKETS_STORAGE::Free(){
	return ReleaseMutex(mut);
};

bool PACKETS_STORAGE::Write(string& data, ulong& outpos){
		PACKETS_STORAGE_SIGN sign;
		sign.length = data.length();
		Poco::MD5Engine md5;
		md5.update(data);
		const Poco::DigestEngine::Digest& digest = md5.digest();
		std::string md5string = Poco::DigestEngine::digestToHex(digest);
		sign.md5val = mql4_md5_part(md5string.c_str(), false);

		Block();
		LARGE_INTEGER p, op;
		DWORD dw, wrBytes;
		p.QuadPart = 0;
		if(!SetFilePointerEx(handle, p, &op, FILE_END)){
				Free();
				return false;	
		}

		outpos = op.QuadPart;

		if(!WriteFile(handle, &sign, sizeof(PACKETS_STORAGE_SIGN), &wrBytes, NULL)){
				Free();
			    return false;
		}

		if(!WriteFile(handle, data.c_str(), sign.length, &wrBytes, NULL)){
				Free();
			    return false;
		}
		sizeOfStorage += (sizeof(PACKETS_STORAGE_SIGN) + sign.length);
		Free();

	return true;
}

bool PACKETS_STORAGE::Get(ulong pos, string& data){
	Block();
	LARGE_INTEGER p, op;
	DWORD dw, wrBytes;
	p.QuadPart = pos;
	if(!SetFilePointerEx(handle, p, &op, FILE_BEGIN)){
				Free();
				return false;	
	}

	PACKETS_STORAGE_SIGN sign;
	if(!ReadFile(handle, &sign, sizeof sign, &dw, NULL)){
			Free();
			return false;
	}

	char *buff = new char[sign.length + 1];
	if(!buff)
	{
		Free();
		return false;
	}

	buff[sign.length] = 0;

	if(!ReadFile(handle, buff, sign.length, &dw, NULL)){
			Free();
			return false;
	}
	if(dw != sign.length){
			Free();
			return false;
	}

	data = buff;
	Poco::MD5Engine md5;
	md5.update(data);
	const Poco::DigestEngine::Digest& digest = md5.digest();
	std::string md5string = Poco::DigestEngine::digestToHex(digest);
	if(sign.md5val != mql4_md5_part(md5string.c_str(), false)){
		Free();
		return false;
	}
	delete [] buff;
	Free();

	return true;
}

PACKETS_STORAGE::~PACKETS_STORAGE(){
	Block();
	CloseHandle(handle);
	CloseHandle(mut);
}

PACKETS_STORAGE* packetsStorage = 0;

class L5_SYSTEM_INFO{
	MYSQL* msH;
	HANDLE mut;
	bool Block();
	bool Free();

	public:
		L5_SYSTEM_INFO(string dbHost, string dbUser, string dbPass, string dbName);
		~L5_SYSTEM_INFO();
		void Set(string key, string val, string symbol = "");
		string Get(string key, string symbol = "");
};

L5_SYSTEM_INFO::L5_SYSTEM_INFO(string dbHost, string dbUser, string dbPass, string dbName){
	msH = mysql_init(NULL);
	if(!msH)
		throw L5Exception("Can't initialize system info");
	bool reconnect = true;
	mysql_options(msH, MYSQL_OPT_RECONNECT, &reconnect);
	msH = mysql_real_connect(msH, dbHost.c_str(), dbUser.c_str(), dbPass.c_str(), dbName.c_str(), 0, NULL, 0);
	if(!msH)
		throw L5Exception("Can't initialize system info");

	std::stringstream  query;
	query << "SET net_read_timeout = 1800"; 
	mysql_query(msH, query.str().c_str());
	query.str("");
	query << "SET net_write_timeout = 1800";
	mysql_query(msH, query.str().c_str());
	query.str("");

	query << "CREATE TABLE IF NOT EXISTS system_info ( "
	   << "gkey varchar(255) NOT NULL, "
	   << "symbol varchar(10) NOT NULL, "
	   << "value TEXT, "
	   << "PRIMARY KEY id (gkey, symbol)"
	   << ") ENGINE=MYISAM";

	if(mysql_query(msH, query.str().c_str())){
		throw L5Exception("Can't initialize system info: " + string(mysql_error(msH)));
	}
	query.str("");

	mut = CreateMutexEx(0,0,0,SYNCHRONIZE|MUTEX_ALL_ACCESS);
	if(!mut)
		throw L5Exception("Can't initialize system info");
}

L5_SYSTEM_INFO::~L5_SYSTEM_INFO(){
	Block();
	CloseHandle(mut);
	if(msH)
		mysql_close(msH);
}

bool L5_SYSTEM_INFO::Block(){
	if(WaitForSingleObject(mut, INFINITE) == WAIT_FAILED)
		return false;
	else
		return true;
};

bool L5_SYSTEM_INFO::Free(){
	return ReleaseMutex(mut);
};

void L5_SYSTEM_INFO::Set(string key, string val, string symbol){
	Block();
	std::stringstream query;
	query << "INSERT INTO system_info (gkey, symbol, value) VALUES ('" << key << "', '" << symbol << "', '" << val << "') ON DUPLICATE KEY UPDATE value = '" << val << "'";
	if(mysql_query(msH, query.str().c_str())){
			Free();
			opLog("Can't set a system setting: " + string(mysql_error(msH)));
			return;
	}
	query.str("");
	Free();
	return;
}

string L5_SYSTEM_INFO::Get(string key, string symbol){
	string result;
	Block();
	std::stringstream query;
	query << "SELECT value FROM system_info WHERE gkey = '" << key << "' AND symbol = '" << symbol << "'";
	if(mysql_query(msH, query.str().c_str())){
			Free();
			opLog("Can't get a system setting: " + string(mysql_error(msH)));
			return result;
	}
	query.str("");
	MYSQL_RES* msRes = mysql_store_result(msH);
	if(mysql_num_rows(msRes)){
		MYSQL_ROW row = mysql_fetch_row(msRes);
		result = row[0]?row[0]:"";
	}
	mysql_free_result(msRes);
	Free();
	return result;
}

L5_SYSTEM_INFO* systemInfo = 0;

ulong lastCommitedSignalMoment = 0;
float lastCurrentPrice = 0;

MT4_EXPFUNC bool mql4_initial_resolver(bool initOnlyDirectory, const wchar_t* sDirectory, wchar_t* symbol, ulong starting_size, float currentBid, float currentAsk, float optimalProfit, int anumOfSelectedSolutions, int anumRowsWithSameOutPacketInSolutions, wchar_t* dbHost, wchar_t* dbUser, wchar_t* dbPass, wchar_t* dbName, wchar_t* dbRHost, wchar_t* dbRUser, wchar_t* dbRPass, wchar_t* dbRName){
	bool res = false;
	try{
		is_deinitialization = false;
		
		char* sD = ToASCII(sDirectory);
		std::string dir = sD;
		delete[] sD;
		char* sM = ToASCII(symbol);
		std::string symbolName = sM;
		delete[] sM;
		l5Symbol = symbolName;
		for(int i = 0; i < l5Symbol.length(); i++){
			l5Symbol[i] = tolower(l5Symbol[i]);
		}
	
		Poco::Path path;
		if(!path.tryParse(dir))
			return res;
		path.assign(dir);
		path.append(Poco::Path(symbolName));
		//depth, directory[], pushDirectory, setFileName

		Poco::File file(path);
		if(!file.exists()){
			file.createDirectories();
		}
		storageDirectory = path;

		if(initOnlyDirectory){
			is_initialization = true;
			return true;
		}

		optimalProfitForPositions = optimalProfit;
		numOfSelectedSolutions = anumOfSelectedSolutions;
		numRowsWithSameOutPacketInSolutions = anumRowsWithSameOutPacketInSolutions;

		starting_size = starting_size < minPacketTableSize?minPacketTableSize:starting_size;
		definedPacketTableStartingSize = starting_size;
		packetTable = new PACKET_TABLE<PACKET_TABLE_DATA>("packets", starting_size);
		if(!packetTable)
			return res;
		timeQueue = new TIME_QUEUE;
		if(!timeQueue)
			return res;
		priceQueue = new PRICE_QUEUE(currentAsk, currentBid);
		if(!priceQueue)
			return res;
	
		momsForRes = new MOMENTS_FOR_RES;
		if(!momsForRes)
			return false;
		packetsStorage = new PACKETS_STORAGE;
			if(!packetsStorage)
				return false;
	
		char* ahost = ToASCII(dbHost);
		std::string host = ahost;
		delete[] ahost;
		char* auser = ToASCII(dbUser);
		std::string user = auser;
		delete[] auser;
		char* apass = ToASCII(dbPass);
		std::string pass = apass?apass:"";
		delete[] apass;
		char* aname = ToASCII(dbName);
		std::string name = aname;
		delete[] aname;
	
		systemInfo = new L5_SYSTEM_INFO(host, user, pass, name);
			if(!systemInfo)
				return false;

		dbH = mysql_init(NULL);
		if(!dbH)
			return false;
		bool reconnect = true;
		mysql_options(dbH, MYSQL_OPT_RECONNECT, &reconnect);
		dbH = mysql_real_connect(dbH, host.c_str(), user.c_str(), pass.c_str(), name.c_str(), 0, NULL, 0);
		if(!dbH)
			return false;

		std::stringstream  query;
		query << "SET net_read_timeout = 1800"; 
		mysql_query(dbH, query.str().c_str());
		query.str("");
		query << "SET net_write_timeout = 1800";
		mysql_query(dbH, query.str().c_str());
		query.str("");

		char* arhost = ToASCII(dbRHost);
		std::string rhost = arhost?arhost:"";
		delete[] arhost;
		if(rhost != ""){
			char* aruser = ToASCII(dbRUser);
			std::string ruser = aruser;
			delete[] aruser;
			char* arpass = ToASCII(dbRPass);
			std::string rpass = arpass?arpass:"";
			delete[] arpass;
			char* arname = ToASCII(dbRName);
			std::string rname = arname;
			delete[] arname;
			dbRH = mysql_init(NULL);
			if(!dbRH)
				return false;
			mysql_options(dbRH, MYSQL_OPT_RECONNECT, &reconnect);
			dbRH = mysql_real_connect(dbRH, rhost.c_str(), ruser.c_str(), rpass.c_str(), rname.c_str(), 0, NULL, 0);
			if(!dbRH)
				return false;

			query.str("");
			query << "SET net_read_timeout = 1800"; 
			mysql_query(dbRH, query.str().c_str());
			query.str("");
			query << "SET net_write_timeout = 1800";
			mysql_query(dbRH, query.str().c_str());
			query.str("");
			query << "SET max_allowed_packet = 52428800";
			mysql_query(dbRH, query.str().c_str());
			query.str("");
		}

		res = true;
		is_initialization = true;
	}
	catch(std::exception& ex){
		throw L5Exception(string("Catched exception: ") + ex.what());
	}
	return res;
}

MT4_EXPFUNC bool mql4_stop_resolver();

MT4_EXPFUNC bool mql4_deinit_resolver(){
	try{
		if(!mql4_stop_resolver())
			return false;
		is_deinitialization = true;

		if(packetTable)
			delete packetTable;
		if(timeQueue)
			delete timeQueue;
		if(priceQueue)
			delete priceQueue;
		if(momsForRes)
			delete momsForRes;
		if(packetsStorage)
			delete packetsStorage;
	
		if(lastCommitedSignalMoment)
		{
			std::stringstream t;
			t << lastCommitedSignalMoment;
			systemInfo->Set("last_signal_moment", t.str(), l5Symbol);
			t.str("");
			t << lastCurrentPrice;
			systemInfo->Set("last_current_price", t.str(), l5Symbol);
		}

		if(systemInfo)
			delete systemInfo;

		if(dbH)
			mysql_close(dbH);
		if(dbRH)
			mysql_close(dbRH);

		if(mutOfWeekendProcessing)
		{
			ReleaseMutex(mutOfWeekendProcessing);
			CloseHandle(mutOfWeekendProcessing);
		}

		is_initialization = false;
	}
	catch(std::exception& ex){
		throw L5Exception(string("Catched exception: ") + ex.what());
	}
	return true;
}

ulong countOfWritingInTimeQueue = 0;
ulong allDurationOfWritingInTimeQueue = 0;

MT4_EXPFUNC bool mql4_write_in_time_queue(float currentPrice, ulong md5p1,  ulong md5p2, char signalType, ulong timestamp, wchar_t* packetHash, bool& is_exists){  //and resolving by early signals
	try{
		if(is_in_weekend_processing)
			return false;

		ulong s = mql4_get_timestamp(true);
		PACKET_TABLE_DATA data;
		memset(&data, 0, sizeof data);

		ulong outPos;

		lastCurrentPrice = currentPrice;
		lastCommitedSignalMoment = timestamp;

		if(!packetTable->Get(md5p1, md5p2, &data, NULL, NULL, NULL, &is_exists))
			return false;
		if(!timeQueue->SignalWrite(signalType == BUY_SIGNAL?data.lastBuyPos:data.lastSellPos, timestamp, currentPrice, outPos))
			return false;

		if(!timeQueue->RegisterMoment(md5p1, md5p2, timestamp, signalType, currentPrice))
			return false;

		if(!is_exists){
			char* pHash =  ToASCII(packetHash);
			string ph = pHash;
			delete [] pHash;
			ulong posInStorage;

			if(!packetsStorage->Write(ph, posInStorage))
				return false;
			data.posInStorage = posInStorage;
		}

		unsigned int *outmoms = 0;
		float *outprices = 0;
		int outsize = 0;
		if(signalType == BUY_SIGNAL){
			data.lastBuyPos = outPos;
			if(data.lastSellPos){
				if(!timeQueue->ResolveQueue(data.lastSellPos, &outmoms, &outprices, outsize))
					return false;
				data.lastSellPos = 0;
			}
		}
		else{
			data.lastSellPos = outPos;
			if(data.lastBuyPos){
				if(!timeQueue->ResolveQueue(data.lastBuyPos, &outmoms, &outprices, outsize))
					return false;
				data.lastBuyPos = 0;
			}
		}

		if(!packetTable->Set(md5p1, md5p2, &data))
			return false;

		//saving moments
		if(outsize){
			for(int i = 0; i < outsize; i++){
				char stype = signalType == BUY_SIGNAL?SELL_SIGNAL:BUY_SIGNAL;
				if(!momsForRes->Write(md5p1, md5p2, outmoms[i], stype, outprices[i], currentPrice))
						return false;
			}
		}

		delete [] outmoms;
		delete [] outprices;
	
		allDurationOfWritingInTimeQueue += (mql4_get_timestamp(true) - s);
		countOfWritingInTimeQueue++;

		return true;
	}
	catch(std::exception& ex){
		throw L5Exception(string("Catched exception: ") + ex.what());
	}
}
   
ulong allDurationOfWritingInPriceQueue = 0;
ulong countOfWritingsInPriceQueue = 0;

MT4_EXPFUNC bool mql4_write_in_price_queue(float stopLoss, float currentPrice, ulong* md5p1, ulong* md5p2, ulong* timestamps, char signalType, int size){
	try{
		if(is_in_weekend_processing)
			return false;

		ulong s = mql4_get_timestamp(true);
		if(!priceQueue->SignalsWrite(stopLoss, currentPrice, timestamps, md5p1, md5p2, signalType, size))
			return false;

		allDurationOfWritingInPriceQueue += (mql4_get_timestamp(true) - s);
		countOfWritingsInPriceQueue++;

		return true;
	}
	catch(std::exception& ex){
		throw L5Exception(string("Catched exception: ") + ex.what());
	}
}

ulong allDurationOfResolvingsInPriceQueue = 0;
ulong countOfResolvingsInPriceQueue = 0;

MT4_EXPFUNC bool mql4_resolving_in_price_queue(float averagePrice) {
	try{
		if(is_in_weekend_processing)
			return false;

		packetTable->TableFlush();

		ulong s = mql4_get_timestamp(true);

		PRICE_QUEUE_ROW *out = 0;
		char* outsignals = 0;
		int outsize;

		if(!priceQueue->ResolveQueues(averagePrice, &out, &outsignals, outsize))
			return false;

		//saving moments
		if(outsize) {
			for(int i = 0; i < outsize; i++)
				if(!momsForRes->Write(out[i].md5p1, out[i].md5p2, out[i].moment, outsignals[i], out[i].startPrice, out[i].stopLoss))
					return false;
		}

		delete [] out;
		delete [] outsignals;

		allDurationOfResolvingsInPriceQueue += (mql4_get_timestamp(true) - s);
		countOfResolvingsInPriceQueue++;

		return true;
	}
	catch(std::exception& ex){
		throw L5Exception(string("Catched exception: ") + ex.what());
	}
}


bool month_processing(){
	string last_moment = systemInfo->Get("last_moment_of_month_processing", l5Symbol);
	int i = 0;

	if(!Poco::NumberParser::tryParse(last_moment, i) || (mql4_get_timestamp() - Poco::NumberParser::parse(last_moment) >= 86400 * 40)){
		opLog("Weekend processing includes month processing!");

		std::stringstream query;
		
		query << "CREATE TABLE " + l5Symbol + "_tmp_optimizer_results AS (SELECT * FROM " + l5Symbol + "_optimizer_results WHERE (deals >= IF(UNIX_TIMESTAMP() - changing_time >= 86400, " 
			   << minDealsForSelectingByCriterion << ", 2)) AND efficency > " << optimalProfitForPositions 
			   << " AND (all_duration / deals) > " << minimalDurationForPostions * 2 << " ORDER BY efficency / all_duration DESC LIMIT " << selectingLimitInMonthProcessing << ")";
		if(mysql_query(dbH, query.str().c_str())){
			opLog("Error in month processing: error in inserting into tmp table: " + string(mysql_error(dbH)));
			return false;
		}
		query.str("");
		query << "INSERT INTO " + l5Symbol + "_tmp_optimizer_results (inmd5p1, inmd5p2, outmd5p1, outmd5p2, efficency, all_duration, deals, average_signal, changing_time) " 
			  << "SELECT inmd5p1, inmd5p2, outmd5p1, outmd5p2, efficency, all_duration, deals, average_signal, changing_time FROM " + l5Symbol + "_optimizer_results " 
			  << " WHERE (deals >= IF(UNIX_TIMESTAMP() - changing_time >= 86400, " << minDealsForSelectingByCriterion << ", 2)) AND (all_duration / deals) > " 
			  << minimalDurationForPostions << " ORDER BY (efficency / deals) DESC LIMIT " << selectingLimitInMonthProcessing;
		if(mysql_query(dbH, query.str().c_str())){
			opLog("Error in month processing: error in second inserting into tmp table: " + string(mysql_error(dbH)));
			return false;
		}
		query.str("");
		query << "TRUNCATE TABLE " + l5Symbol + "_optimizer_results";
		if(mysql_query(dbH, query.str().c_str())){
			opLog("Error in month processing: error in truncating of table: " + string(mysql_error(dbH)));
			return false;
		}
		query.str("");
		query << "INSERT IGNORE INTO " + l5Symbol + "_optimizer_results (inmd5p1, inmd5p2, outmd5p1, outmd5p2, efficency, all_duration, deals, average_signal, changing_time) " 
			  << "SELECT inmd5p1, inmd5p2, outmd5p1, outmd5p2, efficency, all_duration, deals, average_signal, changing_time FROM " + l5Symbol + "_tmp_optimizer_results";
		if(mysql_query(dbH, query.str().c_str())){
			opLog("Error in month processing: error in inserting from tmp table: " + string(mysql_error(dbH)));
			return false;
		}
		query.str("");
		query << "DROP TABLE " + l5Symbol + "_tmp_optimizer_results";
		if(mysql_query(dbH, query.str().c_str())){
			opLog("Error in month processing: error in dropping of tmp table: " + string(mysql_error(dbH)));
			return false;
		}
		query.str("");
		
		query << "SELECT COUNT(*) FROM " + l5Symbol + "_optimizer_results";
		if(mysql_query(dbH, query.str().c_str())){
			opLog("Error in month processing: error in getting num of rows: " + string(mysql_error(dbH)));
			return false;
		}
		query.str("");

		MYSQL_RES* msRes = mysql_store_result(dbH);
		if(mysql_num_rows(msRes)){
			MYSQL_ROW row;
			row = mysql_fetch_row(msRes);
			int totalNum = 0;
			if(Poco::NumberParser::tryParse(string(row[0]), totalNum) && totalNum != 0){
				int start_row = 0;
				int limit = 100000;
				int numItemsInHistory = 0;

				std::set<std::string> foundFiles;
				Poco::Glob::glob(storageDirectory.toString() + "/packet_table_meta_data_of_history_table*.dat", foundFiles);
				std::set<std::string>::iterator it = foundFiles.begin();
				Poco::RegularExpression regexp("([0-9])+\.dat$");
				Poco::RegularExpression::MatchVec posVec;
				for (; it != foundFiles.end(); ++it)
				{
					string path = *it;
					int size;
					if((size = regexp.match(path, 0, posVec)) > 1){
						int num = 0;
						Poco::NumberParser::tryParse(path.substr(posVec[1].offset, posVec[1].length), num);
						if(numItemsInHistory < num)
							numItemsInHistory = num;
					}
				}
				
				PACKET_TABLE<PACKET_TABLE_DATA>** historyTables = new PACKET_TABLE<PACKET_TABLE_DATA>*[numItemsInHistory];
				PACKETS_STORAGE** historyStorages = new PACKETS_STORAGE*[numItemsInHistory];
				
				for(int k = 1; k <= numItemsInHistory; k++){
					char buff[10];
					string tableName = "history_table" + string(itoa(k, buff, 10));
					string pName = "packet_table_meta_data_of_" + tableName + ".dat";
					Poco::Path path(storageDirectory);
					path.append(pName);
					Poco::File file(path);
					if(!file.exists()){
						return false;
					}
					historyTables[k - 1] = new PACKET_TABLE<PACKET_TABLE_DATA>(tableName);
					historyStorages[k - 1] = new PACKETS_STORAGE(k);
				}

				char buff[10];
				string numberOfTheItem = itoa(numItemsInHistory+1, buff, 10);
				string tableName = "history_table" + numberOfTheItem;
				string pName = "packet_table_meta_data_of_" + tableName + ".dat";
				Poco::Path path(storageDirectory);
				PACKET_TABLE<PACKET_TABLE_DATA>* newTable = new PACKET_TABLE<PACKET_TABLE_DATA>(tableName);
				PACKETS_STORAGE* newPackets = new PACKETS_STORAGE(numItemsInHistory + 1);
				bool errWritten = false;

				while(start_row < totalNum){
					query << "SELECT inmd5p1, inmd5p2, outmd5p1, outmd5p2 FROM " + l5Symbol + "_optimizer_results ORDER BY efficency LIMIT " << start_row << ", " << limit;
					if(mysql_query(dbH, query.str().c_str())){
						opLog("Error in month processing: error in getting of rows: " + string(mysql_error(dbH)));
						continue;
					}
					query.str("");

					MYSQL_RES* res2 = mysql_store_result(dbH);
					if(mysql_num_rows(res2)){
						while(row = mysql_fetch_row(res2)){
							string inPacket = "";
							string outPacket = "";
							bool in_exists = false;
							bool out_exists = false;
							PACKET_TABLE_DATA tableData;
							if(!newTable->Get(Poco::NumberParser::parse64(string(row[0])), Poco::NumberParser::parse64(string(row[1])), &tableData, NULL, NULL, NULL, &in_exists))
							{
								opLog("Error in month processing: error in getting of row from new table");
								continue;
							}
							if(!newTable->Get(Poco::NumberParser::parse64(string(row[2])), Poco::NumberParser::parse64(string(row[3])), &tableData, NULL, NULL, NULL, &out_exists))
							{
								opLog("Error in month processing: error in getting of row from new table");
								continue;
							}
							if(in_exists && out_exists)
								continue;

							for(int k = 0; k < numItemsInHistory; k++){
									{
										if(inPacket == "" && !in_exists){
											memset(&tableData, 0, sizeof tableData);

											if(!historyTables[k]->Get(Poco::NumberParser::parse64(string(row[0])), Poco::NumberParser::parse64(string(row[1])), &tableData))
											{
												opLog("Error in month processing: error in getting of packet string by hash");
												continue;
											}
											
											if(tableData.posInStorage && !historyStorages[k]->Get(tableData.posInStorage, inPacket)){
												opLog("Error in month processing: error in getting of packet string by hash");
												continue;
											}
										}
										if(outPacket == "" && !out_exists){
											memset(&tableData, 0, sizeof tableData);

											if(!historyTables[k]->Get(Poco::NumberParser::parse64(string(row[2])), Poco::NumberParser::parse64(string(row[3])), &tableData))
											{
												opLog("Error in month processing: error in getting of packet string by hash");
												continue;
											}
											
											if(tableData.posInStorage && !historyStorages[k]->Get(tableData.posInStorage, outPacket)){
												opLog("Error in month processing: error in getting of packet string by hash");
												continue;
											}
										}
									}

									if((outPacket != "" || out_exists) && (inPacket != "" || in_exists))
										break;
							}

							if((outPacket != "" || out_exists) && (inPacket != "" || in_exists)){
								if(!in_exists){
									memset(&tableData, 0, sizeof tableData);
									if(!newPackets->Write(inPacket, tableData.posInStorage)){
										opLog("Error in month processing: error in writing of packet");
										continue;
									}
									if(!newTable->Set(Poco::NumberParser::parse64(string(row[0])), Poco::NumberParser::parse64(string(row[1])), &tableData)){
										opLog("Error in month processing: error in writing of row into table");
										continue;
									}
								}
								if(!out_exists){
									memset(&tableData, 0, sizeof tableData);
									if(!newPackets->Write(outPacket, tableData.posInStorage)){
										opLog("Error in month processing: error in writing of packet");
										continue;
									}
									if(!newTable->Set(Poco::NumberParser::parse64(string(row[2])), Poco::NumberParser::parse64(string(row[3])), &tableData)){
										opLog("Error in month processing: error in writing of row into table");
										continue;
									}
								}
							}
							else if(!errWritten){
								errWritten = true;
								opLog("Error in month processing: error in getting of packets. Packets do not exist");
							}
						}
					}
					mysql_free_result(res2);

					start_row += limit;
				}

				for(int k = 0; k < numItemsInHistory; k++){
					delete historyTables[k];
					delete historyStorages[k];
					string tableName = "history_table" + string(itoa(k + 1, buff, 10));
					string tName = "packet_table_meta_data_of_" + tableName + ".dat";
					string pName = "history_packets_storage" + string(itoa(k + 1, buff, 10)) + ".dat";
					{
						Poco::Path path(storageDirectory);
						path.append(tName);
						Poco::File file(path);
						if(file.exists()){
							file.remove();
						}
					}
					{
						tName = "packet_table_collision_data_of_" + tableName + ".dat";
						Poco::Path path(storageDirectory);
						path.append(tName);
						Poco::File file(path);
						if(file.exists()){
							file.remove();
						}
					}
					{
						tName = "packet_table_data_of_" + tableName + ".dat";
						Poco::Path path(storageDirectory);
						path.append(tName);
						Poco::File file(path);
						if(file.exists()){
							file.remove();
						}
					}
					{
						Poco::Path path(storageDirectory);
						path.append(pName);
						Poco::File file(path);
						if(file.exists()){
							file.remove();
						}
					}
				}
				delete [] historyStorages;
				delete [] historyTables;

				delete newPackets;
				delete newTable;
				{
					string tableNameFrom = "history_table" + numberOfTheItem;
					string pNameFrom = "history_packets_storage" + numberOfTheItem + ".dat";
					string tableNameTo = "history_table1";
					string pNameTo = "history_packets_storage1.dat";
					{
						string tName1 = "packet_table_meta_data_of_" + tableNameFrom + ".dat";
						string tName2 = "packet_table_meta_data_of_" + tableNameTo + ".dat";
						Poco::Path path1(storageDirectory);
						path1.append(tName1);
						Poco::File file(path1);
						Poco::Path path2(storageDirectory);
						path2.append(tName2);
						file.renameTo(path2.toString());
					}
					{
						string tName1 = "packet_table_collision_data_of_" + tableNameFrom + ".dat";
						string tName2 = "packet_table_collision_data_of_" + tableNameTo + ".dat";
						Poco::Path path1(storageDirectory);
						path1.append(tName1);
						Poco::File file(path1);
						Poco::Path path2(storageDirectory);
						path2.append(tName2);
						file.renameTo(path2.toString());
					}
					{
						string tName1 = "packet_table_data_of_" + tableNameFrom + ".dat";
						string tName2 = "packet_table_data_of_" + tableNameTo + ".dat";
						Poco::Path path1(storageDirectory);
						path1.append(tName1);
						Poco::File file(path1);
						Poco::Path path2(storageDirectory);
						path2.append(tName2);
						file.renameTo(path2.toString());
					}
					{
						Poco::Path path1(storageDirectory);
						path1.append(pNameFrom);
						Poco::File file(path1);
						Poco::Path path2(storageDirectory);
						path2.append(pNameTo);
						file.renameTo(path2.toString());
					}
				}
			}
		}
		mysql_free_result(msRes);

		char buff[100];
		systemInfo->Set("last_moment_of_month_processing", (string) itoa(mql4_get_timestamp(), buff, 10), l5Symbol);
		opLog("Month processing has been completed!!!");
	}

	return true;
}

ulong last_weekend_processing_duration = 0;

bool weekend_processing(bool is_second_step){
	if(!is_second_step){
		if(!mutOfWeekendProcessing){
			mutOfWeekendProcessing = CreateMutexA(NULL, FALSE, "MutOfL5WP");
			if(!mutOfWeekendProcessing)
				throw L5Exception("Cannot creat mutOfWeekendProcessing");
			
			while(!is_stopping_rthread && WaitForSingleObject(mutOfWeekendProcessing, 10000) != WAIT_OBJECT_0)
				Sleep(1000);
			if(is_stopping_rthread)
				return true;
		}

		is_in_weekend_processing = true;
		last_weekend_processing_duration = 0;

		opLog("Weekend processing is started...");

		ulong s = mql4_get_timestamp();

		packetTable->ResetForeach();
		PACKET_TABLE_DATA pdata;
		ulong md5p1,  md5p2;

		double currentPrice = 0;
		int slast_moment = 0;
		Poco::NumberParser::tryParseFloat(systemInfo->Get("last_current_price", l5Symbol), currentPrice);
		Poco::NumberParser::tryParse(systemInfo->Get("last_signal_moment", l5Symbol), slast_moment);
		unsigned int last_moment = slast_moment;

		if(!last_moment || !currentPrice){
			opLog("Error in weekend processing: can't continue weekend processing because last signal moment is not registered");
			return false;
		}

		while(packetTable->Next(md5p1, md5p2, &pdata)){
			unsigned int *outmoms = 0;
			float *outprices = 0;
			int outsize = 0;
			char stype;
			if(pdata.lastSellPos){
				stype = SELL_SIGNAL;
				if(!timeQueue->ResolveQueue(pdata.lastSellPos, &outmoms, &outprices, outsize)){
					opLog("Error in weekend processing: error in time queue resolving");
					continue;
				}
			}
			else if(pdata.lastBuyPos){
				stype = BUY_SIGNAL;
				if(!timeQueue->ResolveQueue(pdata.lastBuyPos, &outmoms, &outprices, outsize)){
					opLog("Error in weekend processing: error in time queue resolving");
					continue;
				}
			}

			//saving moments
			if(outsize){
				for(int i = 0; i < outsize; i++){
					if(!momsForRes->Write(md5p1, md5p2, outmoms[i], stype, outprices[i], currentPrice, last_moment)){
							opLog("Error in weekend processing: error in writing into moments for resolving");
							continue;
					}
				}
			}

			delete [] outmoms;
			delete [] outprices;
		}
		momsForRes->FlushBuff(true);

		last_weekend_processing_duration += (mql4_get_timestamp() - s);
	}
	else{
		ulong s = mql4_get_timestamp();

		std::stringstream query;
		query << "TRUNCATE TABLE " + l5Symbol + "_temp_for_checking";
		if(mysql_query(dbH, query.str().c_str())){
			opLog("Error in weekend processing: error in truncating of table: " + string(mysql_error(dbH)));
			return false;
		}
		query.str("");

		ulong time_for_old_results = mql4_get_timestamp() - 7 * 86400 + 1;
		query << "DELETE FROM " + l5Symbol + "_optimizer_results WHERE (all_duration / deals) <= " << minimalDurationForPostions 
			<< " OR ((efficency / deals) <= " << optimalProfitForPositions << " AND changing_time <= " << time_for_old_results  << ")";
		if(mysql_query(dbH, query.str().c_str())){
			opLog("Error in weekend processing: error in truncating of table: " + string(mysql_error(dbH)));
			return false;
		}
		query.str("");

		//clearing storage directory;
		int numItemsInHistory = 0;

		std::set<std::string> foundFiles;
		Poco::Glob::glob(storageDirectory.toString() + "/packet_table_meta_data_of_history_table*.dat", foundFiles);
		std::set<std::string>::iterator it = foundFiles.begin();
		Poco::RegularExpression regexp("([0-9])+\.dat$");
		Poco::RegularExpression::MatchVec posVec;
		for (; it != foundFiles.end(); ++it)
		{
			string path = *it;
			int size;
			if((size = regexp.match(path, 0, posVec)) > 1){
				int num = 0;
				Poco::NumberParser::tryParse(path.substr(posVec[1].offset, posVec[1].length), num);
				if(numItemsInHistory < num)
					numItemsInHistory = num;
			}
		}
		numItemsInHistory++;
		char buff[10];
		string numberOfTheItem = itoa(numItemsInHistory, buff, 10);

		if(packetTable)
			delete packetTable;
		{
			//meta file
			string pName = "packet_table_meta_data_of_packets.dat";
			Poco::Path path(storageDirectory);
			path.append(pName);
			Poco::File file(path);
			string pName2 = "packet_table_meta_data_of_history_table" + numberOfTheItem + ".dat";
			Poco::Path path2(storageDirectory);
			path2.append(pName2);
			file.renameTo(path2.toString());		
		}
		{
			//collisions file
			string pName = "packet_table_collision_data_of_packets.dat";
			Poco::Path path(storageDirectory);
			path.append(pName);
			Poco::File file(path);
			string pName2 = "packet_table_collision_data_of_history_table" + numberOfTheItem + ".dat";
			Poco::Path path2(storageDirectory);
			path2.append(pName2);
			file.renameTo(path2.toString());		
		}
		{
			//data file
			string pName = "packet_table_data_of_packets.dat";
			Poco::Path path(storageDirectory);
			path.append(pName);
			Poco::File file(path);
			string pName2 = "packet_table_data_of_history_table" + numberOfTheItem + ".dat";
			Poco::Path path2(storageDirectory);
			path2.append(pName2);
			file.renameTo(path2.toString());		
		}

		if(timeQueue)
			delete timeQueue;
		{
			string pName = "time_queue_data.dat";
			Poco::Path path(storageDirectory);
			path.append(pName);
			Poco::File file(path);
			file.remove();
		}
		{
			string pName = "register_moments_data.dat";
			Poco::Path path(storageDirectory);
			path.append(pName);
			Poco::File file(path);
			file.remove();
		}

		if(priceQueue)
			delete priceQueue;
		{
			string pName = "price_queue_sell_data.dat";
			Poco::Path path(storageDirectory);
			path.append(pName);
			Poco::File file(path);
			file.remove();
		}
		{
			string pName = "price_queue_buy_data.dat";
			Poco::Path path(storageDirectory);
			path.append(pName);
			Poco::File file(path);
			file.remove();
		}

		if(momsForRes)
			delete momsForRes;
		{
			string pName = "moments_for_resolving_data.dat";
			Poco::Path path(storageDirectory);
			path.append(pName);
			Poco::File file(path);
			file.remove();
		}

		if(packetsStorage)
			delete packetsStorage;
		{
			string pName = "packets_storage.dat";
			Poco::Path path(storageDirectory);
			path.append(pName);
			Poco::File file(path);
			string pName2 = "history_packets_storage" + numberOfTheItem + ".dat";
			Poco::Path path2(storageDirectory);
			path2.append(pName2);
			file.renameTo(path2.toString());		
		}
		
		packetTable = new PACKET_TABLE<PACKET_TABLE_DATA>("packets", definedPacketTableStartingSize);
		timeQueue = new TIME_QUEUE;
		priceQueue = new PRICE_QUEUE(1, 1);
		momsForRes = new MOMENTS_FOR_RES;
		packetsStorage = new PACKETS_STORAGE;
		
		if(!month_processing())
			return false;

		last_weekend_processing_duration += (mql4_get_timestamp() - s);
		systemInfo->Set("is_invoked_weekend_processing", "yes", l5Symbol);

		opLog("Weekend processing has been completed!!!");

		if(mutOfWeekendProcessing)
		{
			ReleaseMutex(mutOfWeekendProcessing);
			CloseHandle(mutOfWeekendProcessing);
			mutOfWeekendProcessing = 0;
		}
		
		is_in_weekend_processing = false;
	}

	return true;
}

ulong allDurationOfInvokingOfResolvingProcedure = 0;
ulong countOfInvokingOfResolvingProcedure = 0;
ulong lastTakenMomentsForResolving = 0;
ulong lastGeneratedSolutions = 0;
ulong numResolvedResults = 0;

bool consoleMode = false;

DWORD WINAPI resolving_procedure(LPVOID param){
	try{
		bool is_results_updated = true;
		bool is_weekend_processing = false;
		ulong last_sol_updating_time = 0;

		std::stringstream gquery;
		gquery << "CREATE TABLE IF NOT EXISTS " + l5Symbol + "_optimizer_results ( "
		   << "inmd5p1 varchar(50) NOT NULL, "
		   << "inmd5p2 varchar(50) NOT NULL, "
		   << "outmd5p1 varchar(50) NOT NULL, "
		   << "outmd5p2 varchar(50) NOT NULL, " 
		   << "efficency double NOT NULL, "
		   << "all_duration int(11) NOT NULL, "
		   << "deals int(11) NOT NULL, " 
		   << "average_signal int(11) NOT NULL, "
		   << "changing_time int(11) NOT NULL, "
		   << "PRIMARY KEY(inmd5p1, inmd5p2, outmd5p1, outmd5p2), "
		   << "KEY efficency (efficency), " 
		   << "KEY all_duration (all_duration), "
		   << "KEY deals (deals), "
		   << "KEY signals (average_signal),"
		   << "KEY changing_time (changing_time)"
		   << ") ENGINE=MYISAM DEFAULT CHARSET=cp1251;";

		if(mysql_query(dbH, gquery.str().c_str())){
			opLog("Error in resolving thread: error in creating of table: " + string(mysql_error(dbH)));
			return 1;
		}
		gquery.str("");

		gquery << "CREATE TABLE IF NOT EXISTS " + l5Symbol + "_temp_for_checking ( "
		   << "gkey bigint(20) NOT NULL, "
		   << "md5p1 bigint(20) NOT NULL, "
		   << "PRIMARY KEY gkey (gkey)"
		   << ") ENGINE=MEMORY";

		if(mysql_query(dbH, gquery.str().c_str())){
			opLog("Error in resolving thread: error in creating of table: " + string(mysql_error(dbH)));
			return 1;
		}
		gquery.str("");


		gquery << "CREATE TABLE IF NOT EXISTS " + l5Symbol + "_optimizer_solutions ("
		   << "id INT NOT NULL AUTO_INCREMENT,"
		   << "criterion int NOT NULL, "
		   << "priority int NOT NULL, "
		   << "inpacket TEXT, "
		   << "outpacket TEXT, "
		   << "desired_signal int, "
		   << "adapted_by_duration int, "
		   << "PRIMARY KEY id (id), "
		   << "KEY criterium (criterion),"
		   << "KEY prioriry (priority)"
		   << ") ENGINE=MyIsam DEFAULT CHARSET=cp1251;";

		if(mysql_query(dbH, gquery.str().c_str())){
			opLog("Error in resolving thread: error in creating of table: " + string(mysql_error(dbH)));
			return 1;
		}
	
		while(!is_stopping_rthread || is_weekend_processing){
			MOMENTS_FOR_RES_ROW* moments = 0;
		
			int outsize;
			if(!momsForRes->Get(&moments, outsize, is_weekend_processing?100500:20500))
			{
				Sleep(10);
				opLog("Error in resolving thread: can't get moments for resolving");
				continue;
			};

			ulong s = mql4_get_timestamp();
			int resCount = 0;

			if(!consoleMode && outsize){
				bool* is_deleted = 0;
				ulong* toutmd5p1 = 0;
				ulong* toutmd5p2 = 0;
				unsigned int* toutmoment = 0;
				float* tefficency = 0;
				try{
					is_deleted = new bool[outsize];
					toutmd5p1 = new ulong[outsize];
					toutmd5p2 = new ulong[outsize];
					toutmoment = new unsigned int[outsize];
					tefficency = new float[outsize];
				}	
				catch(...)
				{
					Sleep(10);
					opLog("Error in resolving thread: can't allocate memory");
					continue;
				}

				memset(is_deleted, 0, outsize);
				memset(toutmd5p1, 0, outsize);
				memset(toutmd5p2, 0, outsize);
				memset(toutmoment, 0, outsize);
				memset(tefficency, 0, outsize);

				for(int j = 0; j < outsize; j++){
					if(!timeQueue->FindPacketsInArea(moments[j].start_moment, moments[j].end_moment, moments[j].start_price, moments[j].signalType == BUY_SIGNAL?SELL_SIGNAL:BUY_SIGNAL, toutmd5p1[j], toutmd5p2[j], tefficency[j], toutmoment[j])){
							opLog("Error in resolving thread: can't find packets in area");
							continue;
					}
				}

				for(int i = 0; i < outsize; i++){
					if(is_deleted[i])
						continue;

					ulong outmd5p1 = toutmd5p1[i];
					ulong outmd5p2 = toutmd5p2[i];
					unsigned int outmoment = toutmoment[i];

					float efficency = 0;
					int deals = 0;
					ulong all_duration = 0;
					int average_signal = 0;

					int deletedDuplicatesNum = 0;
			
					if(outmoment){
						//grouping, filtering and clearing from noise
						std::vector<float> eff;
						std::vector<int> sig;
						std::vector<ulong> outmoms;
						std::vector<ulong> start_moms;
						std::vector<bool> dels;

						eff.push_back(tefficency[i]);
						start_moms.push_back(moments[i].start_moment);
						sig.push_back(moments[i].signalType == BUY_SIGNAL?1:-1);
						outmoms.push_back(toutmoment[i]);
						dels.push_back(false);

						for(int j = i + 1; j < outsize; j++){
							if(!is_deleted[j] && moments[i].md5p1 == moments[j].md5p1 && moments[i].md5p2 == moments[j].md5p2){
								if(moments[i].start_moment == moments[j].start_moment)
								{
									is_deleted[j] = true;
									deletedDuplicatesNum++;
									continue;
								}

								if(outmd5p1 == toutmd5p1[j] && outmd5p2 == toutmd5p2[j]){
									eff.push_back(tefficency[j]);
									start_moms.push_back(moments[j].start_moment);
									sig.push_back(moments[j].signalType == BUY_SIGNAL?1:-1);
									outmoms.push_back(toutmoment[j]);
									dels.push_back(false);

									is_deleted[j] = true;
								}
							}
						}

						//clearing from noise
						if(dels.size()){
							int len = dels.size();
							int min_startmoment;
							int posj;
							for(int j = 0; j < len; j++){
								if(!dels[j]){
									min_startmoment = start_moms[j];
									posj = j;
									dels[j] = true;
									for(int k = j + 1; k < len; k++){
										if(!dels[k] && outmoms[j] == outmoms[k] && sig[j] == sig[k]){
											dels[k] = true;
											if(min_startmoment > start_moms[k]){
												posj = k;
												min_startmoment = start_moms[k];
											}
										}
									}

									deals++;
									efficency += eff[posj];
									average_signal += sig[posj];
									all_duration += (outmoms[posj] - start_moms[posj]);
								}
							}
						}
				
						std::stringstream  query;  
						bool needToWrite = true;

						ulong hashKey = (moments[i].md5p1  ^  moments[i].md5p2)  +  moments[i].start_moment;
						hashKey = (hashKey & 0xF) + (hashKey >> 8);
						ulong md5p1forCheck = (moments[i].md5p1 & 0xF) + (moments[i].md5p1 >> 8);
						std::string md5p1forCheckDb = "0";

						while(Poco::NumberParser::parse64(md5p1forCheckDb) != md5p1forCheck){
								needToWrite = false;
								query << "SELECT gkey, md5p1 FROM " + l5Symbol + "_temp_for_checking WHERE gkey = " << hashKey;
								if(mysql_query(dbH, query.str().c_str())){
										opLog("Error in resolving thread: error in checking by database: " + string(mysql_error(dbH)));
										query.str("");
										continue;
								}
								query.str("");
								MYSQL_RES* msRes = mysql_store_result(dbH);
								if(mysql_num_rows(msRes)){
									MYSQL_ROW row = mysql_fetch_row(msRes);
									md5p1forCheckDb = row[1];
								}
								else{
									needToWrite = true;
									mysql_free_result(msRes);
									break;
								}
								mysql_free_result(msRes);
								hashKey++;
						}
					
						if(needToWrite){
							is_results_updated = true;
							query << "INSERT INTO " + l5Symbol + "_optimizer_results (inmd5p1 , inmd5p2, outmd5p1, outmd5p2, efficency, all_duration, deals, average_signal, changing_time) VALUES ('" 
								<< moments[i].md5p1 << "', '" << moments[i].md5p2 <<  "', '" << outmd5p1 << "', '" << outmd5p2 << "', " << efficency << ", " << all_duration << ", " << deals << ", " <<  (int) (average_signal) << ", " << mql4_get_timestamp() << " ) "
								<< " ON DUPLICATE KEY UPDATE efficency = efficency + " << efficency <<", deals = deals + " << deals << ", average_signal = average_signal + " <<  (int) (average_signal) 
								<< ", all_duration = all_duration + " << (all_duration) << ", changing_time = " << mql4_get_timestamp();
							if(mysql_query(dbH, query.str().c_str())){
								opLog("Error in resolving thread: error in inserting into database: " + string(mysql_error(dbH)));
								continue;
							}
							query.str("");

							query << "INSERT INTO " + l5Symbol + "_temp_for_checking (gkey, md5p1) VALUES (" << hashKey << ", " << md5p1forCheck << ")";
							if(mysql_query(dbH, query.str().c_str())){
									opLog("Error in resolving thread: error in checking by database: " + string(mysql_error(dbH)));
									continue;
							}
							query.str("");

							resCount++;
						}
					}
				}
		
				delete [] is_deleted;
				delete [] moments;
				delete [] toutmd5p1;
				delete [] toutmd5p2;
				delete [] toutmoment;
				delete [] tefficency;

				allDurationOfInvokingOfResolvingProcedure += (mql4_get_timestamp() - s);
				countOfInvokingOfResolvingProcedure++;
				lastGeneratedSolutions = resCount;
				lastTakenMomentsForResolving = outsize;
				if(is_weekend_processing){
					last_weekend_processing_duration += (mql4_get_timestamp() - s);
				}

				std::stringstream query;
				query.str("");
				query << "SELECT COUNT(*) FROM " + l5Symbol + "_optimizer_results";
				if(mysql_query(dbH, query.str().c_str())){
					opLog("Error in resolving thread: error getting num rows in results' table: " + string(mysql_error(dbH)));
					continue;
				}
				query.str("");

				MYSQL_RES * msRes = mysql_store_result(dbH);
				if(mysql_num_rows(msRes)){
					MYSQL_ROW row = mysql_fetch_row(msRes);
					numResolvedResults = Poco::NumberParser::parse(string(row[0]));
				}
				mysql_free_result(msRes);
			}
		
			//getting solutions
			if(mql4_get_timestamp() - last_sol_updating_time >= intervalForGettingSolutions && is_results_updated){
				timeQueue->ClearBuffOfRegisteredMoments();
				is_results_updated = false;
				bool error_about_finding_packet_printed = false;

				std::stringstream query;
				query.str("");
				query << "SELECT COUNT(*) FROM " + l5Symbol + "_optimizer_results";
				if(mysql_query(dbH, query.str().c_str())){
					opLog("Error in resolving thread: error getting num rows in results' table: " + string(mysql_error(dbH)));
					continue;
				}
				query.str("");
				MYSQL_RES * msRes = mysql_store_result(dbH);
				if(mysql_num_rows(msRes)){
					MYSQL_ROW row = mysql_fetch_row(msRes);
					numResolvedResults = Poco::NumberParser::parse(string(row[0]));
				}
				mysql_free_result(msRes);

				//clearing from WRONG ROWS
				query.str("");
				query << "DELETE FROM " + l5Symbol + "_optimizer_results WHERE efficency / deals >= 50 OR all_duration / deals > 7 * 3600 * 24";
				if(mysql_query(dbH, query.str().c_str())){
					opLog("Error in resolving thread: error in clearing of results' table from wrong rows: " + string(mysql_error(dbH)));
					continue;
				}
				query.str("");

				int criterions_num = 2;
				int start_row = 0;
				int limit = 4000;
				std::string prevMd5OfOutPacket = "";
				int repeatings = 0;

				last_sol_updating_time = mql4_get_timestamp();
			
				if(limit < numOfSelectedSolutions){
					opLog("Error in resolving thread: numOfSelectedSolutions more than limit");
					return 1;
				}

				std::vector<bool> deleted_criterions;
				std::vector<int> written_rows_by_criterion;
				for(int i = 0; i < criterions_num; i++){
					deleted_criterions.push_back(false);
					written_rows_by_criterion.push_back(0);
				}

				for(int i = 1; i <= criterions_num; i++){
					query.str("");
					if(!deleted_criterions[i - 1]){
						query << "DELETE FROM " + l5Symbol + "_optimizer_solutions WHERE criterion = " << i;
						if(mysql_query(dbH, query.str().c_str())){
							opLog("Error in resolving thread: error in deleting criterion: " + string(mysql_error(dbH)));
							continue;
						}
						query.str("");
						deleted_criterions[i - 1] = true;
					}

					switch(i){
						case 1: query << "SELECT inmd5p1, inmd5p2, outmd5p1, outmd5p2, average_signal, (all_duration / deals) AS dur FROM  " + l5Symbol + "_optimizer_results "
									<< " WHERE (deals >= IF(UNIX_TIMESTAMP() - changing_time >= 86400, " << minDealsForSelectingByCriterion << ", 2)) AND (all_duration / deals) > " << minimalDurationForPostions << " ORDER BY (efficency / deals) DESC, (all_duration / deals) ASC, deals DESC, changing_time DESC LIMIT " << start_row << ", " << limit;
						break;
						case 2: query << "SELECT inmd5p1, inmd5p2, outmd5p1, outmd5p2, average_signal, (all_duration / deals) AS dur FROM  " + l5Symbol + "_optimizer_results "
									<< " WHERE (deals >= IF(UNIX_TIMESTAMP() - changing_time >= 86400, " << minDealsForSelectingByCriterion << ", 2)) AND efficency > " << optimalProfitForPositions 
									<< " AND (all_duration / deals) > " << minimalDurationForPostions * 2 << " ORDER BY efficency / all_duration DESC LIMIT " << start_row << ", " << limit;
						break;
					}

					if(mysql_query(dbH, query.str().c_str())){
							opLog("Error in resolving thread: error in getting by criterion: " + string(mysql_error(dbH)));
							continue;
					}
					query.str("");

					MYSQL_RES* msRes = mysql_store_result(dbH);
					if(mysql_num_rows(msRes)){
						MYSQL_ROW row;
						while(row = mysql_fetch_row(msRes)){
							query.str("");
							string md5OutPacket = string(row[2]) + string(row[3]);
							if(md5OutPacket != prevMd5OfOutPacket || repeatings < numRowsWithSameOutPacketInSolutions){
								if(md5OutPacket != prevMd5OfOutPacket){
									prevMd5OfOutPacket = md5OutPacket;
									repeatings = 0;
								}
							}
							else{
								continue;
							}
						
							string inPacket, outPacket;
							PACKET_TABLE_DATA tableData;
							memset(&tableData, 0, sizeof tableData);

							if(!packetTable->Get(Poco::NumberParser::parse64(string(row[0])), Poco::NumberParser::parse64(string(row[1])), &tableData))
							{
								opLog("Error in resolving thread: error in getting of packet string by hash");
								continue;
							}
							if(tableData.posInStorage && !packetsStorage->Get(tableData.posInStorage, inPacket)){
								opLog("Error in resolving thread: error in getting of packet string by hash");
								continue;
							}
							memset(&tableData, 0, sizeof tableData);
							if(!packetTable->Get(Poco::NumberParser::parse64(string(row[2])), Poco::NumberParser::parse64(string(row[3])), &tableData))
							{
								opLog("Error in resolving thread: error in getting of packet string by hash");
								continue;
							}
							if(tableData.posInStorage && !packetsStorage->Get(tableData.posInStorage, outPacket)){
								opLog("Error in resolving thread: error in getting of packet string by hash");
								continue;
							}

							if(inPacket == "" || outPacket == ""){
								int fNum = 1;
								char buff[10];
								while(true){
									string tableName = "history_table" + string(itoa(fNum, buff, 10));
									string pName = "packet_table_meta_data_of_" + tableName + ".dat";
									Poco::Path path(storageDirectory);
									path.append(pName);
									Poco::File file(path);
									if(!file.exists()){
										break;
									}
									
									{
										PACKET_TABLE<PACKET_TABLE_DATA> historyTable(tableName);
										PACKETS_STORAGE historyStorage(fNum);
										if(inPacket == ""){
											memset(&tableData, 0, sizeof tableData);

											if(!historyTable.Get(Poco::NumberParser::parse64(string(row[0])), Poco::NumberParser::parse64(string(row[1])), &tableData))
											{
												opLog("Error in resolving thread: error in getting of packet string by hash");
												continue;
											}
											
											if(tableData.posInStorage && !historyStorage.Get(tableData.posInStorage, inPacket)){
												opLog("Error in resolving thread: error in getting of packet string by hash");
												continue;
											}
										}
										if(outPacket == ""){
											memset(&tableData, 0, sizeof tableData);

											if(!historyTable.Get(Poco::NumberParser::parse64(string(row[2])), Poco::NumberParser::parse64(string(row[3])), &tableData))
											{
												opLog("Error in resolving thread: error in getting of packet string by hash");
												continue;
											}
											
											if(tableData.posInStorage && !historyStorage.Get(tableData.posInStorage, outPacket)){
												opLog("Error in resolving thread: error in getting of packet string by hash");
												continue;
											}
										}
									}

									if(outPacket != "" && inPacket != "")
										break;

									fNum++;
								}

								if(inPacket == "" || outPacket == ""){
									if(!error_about_finding_packet_printed)
										;//opLog("Error in resolving thread: can't get packet by hash");
									error_about_finding_packet_printed = true;
									continue;
								}
							}
						
							//writing;
							query << "INSERT INTO " + l5Symbol + "_optimizer_solutions (criterion, priority, inpacket, outpacket, desired_signal, adapted_by_duration) VALUES ("
								<< i << ", " << written_rows_by_criterion[i - 1] + 1 << ", '" << inPacket << "', '" << outPacket << "', " << (Poco::NumberParser::parse64(row[4]) < 0?SELL_SIGNAL:BUY_SIGNAL) << ", " << string(row[5]) << ")";
							if(mysql_query(dbH, query.str().c_str())){
								opLog("Error in resolving thread: error in writing into solutions table: " + string(mysql_error(dbH)));
								continue;
							}
							query.str("");

							written_rows_by_criterion[i - 1]++;
							repeatings++;
							if(written_rows_by_criterion[i - 1] >= numOfSelectedSolutions)
							{
								break;
							}
						}

						mysql_free_result(msRes);
					}
					else{
						mysql_free_result(msRes);
						continue;
					}

					if(written_rows_by_criterion[i - 1] < numOfSelectedSolutions)
					{
						i--;
						start_row += limit;
					}
				}

				//loading solutions to remote server
				if(dbRH){
					query.str("");
					query << "SELECT id, criterion, priority, inpacket, outpacket, desired_signal, adapted_by_duration FROM " + l5Symbol + "_optimizer_solutions";
					if(mysql_query(dbH, query.str().c_str())){
							opLog("Error in resolving thread: error in loading solutions to remote server: " + string(mysql_error(dbH)));
							continue;
					}
					query.str("");

					MYSQL_RES* msRes = mysql_store_result(dbH);
					if(mysql_num_rows(msRes)){
						int count = 0;
						bool success = false;
						do{
							count++;
							query.str("");
							query << "DELETE FROM " + l5Symbol + "_optimizer_solutions";
							if(mysql_query(dbRH, query.str().c_str())){
									//opLog("Error in resolving thread: error in loading solutions to remote server: " + string(mysql_error(dbRH)));
									continue;
							}
							query.str("");

							MYSQL_ROW row;
							query << "INSERT INTO " + l5Symbol + "_optimizer_solutions (id, criterion, priority, inpacket, outpacket, desired_signal, adapted_by_duration) VALUES ";
							int count = 0;

							while(row = mysql_fetch_row(msRes)){
								count++;
								query << "(" << row[0] << "," << row[1] << "," << row[2] << ",'"<< row[3] << "','" << row[4] << "',"<< row[5] << "," << row[6] << ")";
								if(count != mysql_num_rows(msRes)){
									query << ",";
								}
							}

							if(mysql_query(dbRH, query.str().c_str())){
									opLog("Error in resolving thread: error in loading solutions to remote server: " + string(mysql_error(dbRH)));
									continue;
							}
							query.str("");
							success = true;
						}while(!success && count < 5);
					}
					mysql_free_result(msRes);
				}
			}
		
			Poco::DateTime now;
			if(!outsize){
				//weekend processing
				if(((now.dayOfWeek() == 5  && now.hour() >= 23) || now.dayOfWeek() == 6 || (now.dayOfWeek() == 0 && now.hour() <= 12)) && (systemInfo->Get("is_invoked_weekend_processing", l5Symbol) == "no" || systemInfo->Get("is_invoked_weekend_processing", l5Symbol) == "")){
					if(!is_weekend_processing){
						if(lastCommitedSignalMoment)
						{
							std::stringstream t;
							t << lastCommitedSignalMoment;
							systemInfo->Set("last_signal_moment", t.str(), l5Symbol);
							t.str("");
							t << lastCurrentPrice;
							systemInfo->Set("last_current_price", t.str(), l5Symbol);
						}
					}

					weekend_processing(is_weekend_processing);
					is_weekend_processing = !is_weekend_processing;
				}
			}

			if(now.dayOfWeek() >= 1 && now.dayOfWeek() < 3){
				systemInfo->Set("is_invoked_weekend_processing", "no", l5Symbol);
			}

			int ms = 0;
			while(!is_stopping_rthread && ms++ < ((!is_weekend_processing)?1000:10))
				Sleep(10);	
		}
		return 0;
	}
	catch(std::exception& ex){
		throw L5Exception(string("Catched exception: ") + ex.what());
	}
};

MT4_EXPFUNC bool mql4_run_resolver(){
	
	if(rThread != 0)
	{
			is_stopping_rthread = true;
			if(WaitForSingleObject(rThread, INFINITE) == WAIT_FAILED)
					return false;
	}

	is_stopping_rthread = false;
	rThread = CreateThread(NULL, 0, resolving_procedure, NULL, NULL, NULL);
	
	if(!rThread)
		return false;
	
	return true;
}

MT4_EXPFUNC bool mql4_stop_resolver(){
	if(rThread != 0){
		is_stopping_rthread = true;
		if(WaitForSingleObject(rThread, INFINITE) == WAIT_FAILED)
			return false;
			
		CloseHandle(rThread);
		rThread = 0;
	} 
	
	return true;
}

MT4_EXPFUNC bool mql4_get_packet_from_storage(ulong md5p1, ulong md5p2, int& pointer, int& size){
	PACKET_TABLE_DATA data;
	if(!packetTable->Get(md5p1, md5p2, &data))
		return false;
	
	string packet;
	if(!packetsStorage->Get(data.posInStorage, packet))
		return false;

	size = packet.length();
	char* result = new char[size + 1];
	if(!result)
		return false;
	strcpy(result, packet.c_str());
	pointer = (int) result;

	return true;
};

#pragma pack(push, 1)
struct INFO_ABOUT_OPTIMIZER{
	int size_of_packet_table;
	int num_rows_in_packet_table;
	int num_collisions_in_packet_table;
	int signals_num_in_time_queue;
	int registered_moments_num;
	int sell_signals_in_price_queue;
	int buy_signals_in_price_queue;
	int num_moments_for_resolving;
	int num_moments_for_resolving_in_buffer;
	int averageDurationOfWritingInTimeQueue;
	int averageDurationOfWritingInPriceQueue;
	int averageDurationOfResolvingInPriceQueue;
	int averageDurationOfResolvingProcedure;
	int lastGeneratedSolutions;
	int lastMomentsForResolving;
	int numResolvedResults;
	int lastWeekendProcessingDuration;
	int is_in_weekend_processing;

} info_about_optimizer;
#pragma pack(pop)

MT4_EXPFUNC int mql4_get_info_about_optimizer(int index){
	int val = 0;
	if(is_in_weekend_processing)
	{
		if(index == 18)
			return 1;
		else
			return val;
	}
	switch(index){
		case 1:
			info_about_optimizer.size_of_packet_table = packetTable->meta.size;
			val = info_about_optimizer.size_of_packet_table;
		break;
		case 2:
			info_about_optimizer.num_rows_in_packet_table = packetTable->meta.rows_written;
			val = info_about_optimizer.num_rows_in_packet_table;
		break;
		case 3:
			info_about_optimizer.num_collisions_in_packet_table = packetTable->meta.num_collisions;
			val = info_about_optimizer.num_collisions_in_packet_table;
		break;
		case 4:
			info_about_optimizer.signals_num_in_time_queue = timeQueue->GetSignalsNum();
			val = info_about_optimizer.signals_num_in_time_queue;
		break;
		case 5:
			info_about_optimizer.registered_moments_num = timeQueue->GetRegisteredNum();
			val = info_about_optimizer.registered_moments_num;
		break;
		case 6:
			info_about_optimizer.sell_signals_in_price_queue = priceQueue->GetSignalsInSell();
			val = info_about_optimizer.sell_signals_in_price_queue;
		break;
		case 7:
			info_about_optimizer.buy_signals_in_price_queue = priceQueue->GetSignalsInBuy();
			val = info_about_optimizer.buy_signals_in_price_queue;
		break;
		case 8:
			info_about_optimizer.num_moments_for_resolving = momsForRes->GetSignalsNum();
			val = info_about_optimizer.num_moments_for_resolving;
		break;
		case 9:
			info_about_optimizer.num_moments_for_resolving_in_buffer = momsForRes->GetSignalsInBuffer();
			val = info_about_optimizer.num_moments_for_resolving_in_buffer;
		break;
		case 10:
			info_about_optimizer.averageDurationOfWritingInTimeQueue = countOfWritingInTimeQueue?allDurationOfWritingInTimeQueue / countOfWritingInTimeQueue:0;
			val = info_about_optimizer.averageDurationOfWritingInTimeQueue;
		break;
		case 11:
			info_about_optimizer.averageDurationOfWritingInPriceQueue = countOfWritingsInPriceQueue?allDurationOfWritingInPriceQueue / countOfWritingsInPriceQueue:0;
			val = info_about_optimizer.averageDurationOfWritingInPriceQueue;
		break;
		case 12:
			info_about_optimizer.averageDurationOfResolvingInPriceQueue = countOfResolvingsInPriceQueue?allDurationOfResolvingsInPriceQueue / countOfResolvingsInPriceQueue:0;
			val = info_about_optimizer.averageDurationOfResolvingInPriceQueue ;
		break;
		case 13:
			info_about_optimizer.averageDurationOfResolvingProcedure = countOfInvokingOfResolvingProcedure?allDurationOfInvokingOfResolvingProcedure / countOfInvokingOfResolvingProcedure:0;
			val = info_about_optimizer.averageDurationOfResolvingProcedure;
		break;
		case 14:
			info_about_optimizer.lastGeneratedSolutions = lastGeneratedSolutions;
			val = info_about_optimizer.lastGeneratedSolutions;
		break;
		case 15:
			info_about_optimizer.lastMomentsForResolving = lastTakenMomentsForResolving;
			val = info_about_optimizer.lastMomentsForResolving;
		break;
		case 16:
			info_about_optimizer.numResolvedResults = numResolvedResults;
			val = info_about_optimizer.numResolvedResults;
		break;
		case 17:
			info_about_optimizer.lastWeekendProcessingDuration = last_weekend_processing_duration;
			val = info_about_optimizer.lastWeekendProcessingDuration;
		break;
		case 18:
			info_about_optimizer.is_in_weekend_processing = (int) is_in_weekend_processing;
			val = info_about_optimizer.is_in_weekend_processing;
		break;

	}
	
	return val;
}

bool mql4_mysql_reconnect(int dbHandle){
	int reconnect;
	if(mysql_options((MYSQL*) dbHandle, MYSQL_OPT_RECONNECT, &reconnect))
		return false;
	return true;
}

/*
 * END FOR RESOLVING GAINS
 */